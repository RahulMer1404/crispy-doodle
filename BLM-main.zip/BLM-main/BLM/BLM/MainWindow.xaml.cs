﻿using BLM.ViewModels;

namespace BLM
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow
    {
        #region Variables
        internal MainViewModel MainViewModel { get; private set; }
        #endregion

        #region Ctor
        public MainWindow()
        {
            InitializeComponent();
            
            MainViewModel = new MainViewModel();
            DataContext = MainViewModel;
            //this.Resources["inputFormat"] = StaticHelperClass.InputFormat;
        }
        #endregion
    }
}
