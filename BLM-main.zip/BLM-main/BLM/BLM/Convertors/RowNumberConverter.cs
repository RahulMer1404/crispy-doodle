﻿using System;
using System.Windows.Data;
using System.Windows.Controls;

namespace BLM.Convertors
{
    public class RowNumberConverter : IMultiValueConverter
    {
        #region IMultiValueConverter Members
        /// <summary>
        /// this is for convert items to row number
        /// </summary>
        /// <param name="values"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            //get the list view and the list view item
            ListViewItem item = values[0] as ListViewItem;
            ListView listView = values[1] as ListView;

            int index = 0;
            if (listView != null)
            {
                if (item != null)
                {
                    index = listView.Items.IndexOf(item.Content) + 1;

                    return index.ToString();
                }
            }

            return index.ToString();
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}
