﻿using BLM.Helpers.Common;
using BLM.Helpers.Repositories;
using BLM.Interfaces;
using BLM.Models;
using BLM.Views;
using System.Collections.ObjectModel;
using System.Windows.Input;
using System.Linq;
using System.Windows;
using System;
using System.Collections.Generic;
using System.Windows.Controls;
using System.ComponentModel;
using System.Windows.Media;
//using System.Windows.Data;

namespace BLM.ViewModels
{
    public class MainViewModel : BaseModel
    {
        #region Variables
        public IBlmRepository BlmRepository = new BlmRepository();
        BlankSheetRegistrationWindow _blankSheetRegistrationWindow;
        SortOptions _sortOptions;
        FilterOptions _filterOptions;
        string _columnName = string.Empty;
        #endregion

        #region Ctor
        public MainViewModel()
        {
            CollectionOfBlankSheet = BlmRepository.GetAllBlankSheet();
            InputUnit = BlmRepository.GetInputUnit();

            CollectionOfListSortOptionModels = new ObservableCollection<SortOptionModel>
            {
                new SortOptionModel() {Title = "Blank ID", ImageSource = "", TitleNumber = 1, PropertyName = "BlankId"},
                new SortOptionModel() {Title = "Material", ImageSource = "", TitleNumber = 2, PropertyName = "NewMaterial"},
                new SortOptionModel() {Title = "Thickness", ImageSource = "", TitleNumber = 3, PropertyName = "NewThickness"},
                new SortOptionModel() {Title = "X-Size", ImageSource = "", TitleNumber = 4, PropertyName = "NewSizeX"},
                new SortOptionModel() {Title = "Y-Size", ImageSource = "", TitleNumber = 5, PropertyName = "NewSizeY"}
            };

            CollectionOfSelectedSortOptionModels = new ObservableCollection<SortOptionModel>
            {
                new SortOptionModel() {Title = "", ImageSource = ""},
                new SortOptionModel() {Title = "", ImageSource = ""},
                new SortOptionModel() {Title = "", ImageSource = ""},
                new SortOptionModel() {Title = "", ImageSource = ""},
                new SortOptionModel() {Title = "", ImageSource = ""}
            };
        }
        #endregion

        #region Properties
        private ObservableCollection<BlankSheetModel> _collectionOfBlankSheet;
        public ObservableCollection<BlankSheetModel> CollectionOfBlankSheet
        {
            get { return _collectionOfBlankSheet; }
            set
            {
                _collectionOfBlankSheet = value;
                //BlankSheetCollectionViewSource = new CollectionViewSource { Source = _collectionOfBlankSheet };
                OnPropertyChanged("CollectionOfBlankSheet");
            }
        }

        private ObservableCollection<BlankSheetModel> _collectionOfBlankSheetBackup = new ObservableCollection<BlankSheetModel>();
        public ObservableCollection<BlankSheetModel> CollectionOfBlankSheetBackup
        {
            get { return _collectionOfBlankSheetBackup; }
            set
            {
                _collectionOfBlankSheetBackup = value;
                OnPropertyChanged("CollectionOfBlankSheetBackup");
            }
        }

        private BlankSheetModel _selectedBlankSheet;
        public BlankSheetModel SelectedBlankSheet
        {
            get { return _selectedBlankSheet; }
            set
            {
                _selectedBlankSheet = value;
                OnPropertyChanged("SelectedBlankSheet");
            }
        }

        private BlankSheetModel _selectedGroupBlankSheet;
        public BlankSheetModel SelectedGroupBlankSheet
        {
            get { return _selectedGroupBlankSheet; }
            set
            {
                _selectedGroupBlankSheet = value;
                OnPropertyChanged("SelectedGroupBlankSheet");
            }
        }

        private string _inputUnit;
        public string InputUnit
        {
            get { return _inputUnit; }
            set
            {
                _inputUnit = value;
                OnPropertyChanged("InputUnit");
            }
        }

        private bool _isGroupEdit;
        public bool IsGroupEdit
        {
            get { return _isGroupEdit; }
            set
            {
                _isGroupEdit = value;
                OnPropertyChanged("IsGroupEdit");
            }
        }

        private bool _isBlankIdFocused;
        public bool IsBlankIdFocused
        {
            get
            {
                return _isBlankIdFocused;
            }
            set
            {
                if (_isBlankIdFocused == value)
                {
                    _isBlankIdFocused = false;
                    RaisePropertyChanged("IsBlankIdFocused");
                }
                _isBlankIdFocused = value;
                RaisePropertyChanged("IsBlankIdFocused");
            }
        }

        private bool _isMaterialFocused;
        public bool IsMaterialFocused
        {
            get
            {
                return _isMaterialFocused;
            }
            set
            {
                if (_isMaterialFocused == value)
                {
                    _isMaterialFocused = false;
                    RaisePropertyChanged("IsMaterialFocused");
                }
                _isMaterialFocused = value;
                RaisePropertyChanged("IsMaterialFocused");
            }
        }

        private bool _isThicknessFocused;
        public bool IsThicknessFocused
        {
            get
            {
                return _isThicknessFocused;
            }
            set
            {
                if (_isThicknessFocused == value)
                {
                    _isThicknessFocused = false;
                    RaisePropertyChanged("IsThicknessFocused");
                }
                _isThicknessFocused = value;
                RaisePropertyChanged("IsThicknessFocused");
            }
        }

        private bool _isSizeXFocused;
        public bool IsSizeXFocused
        {
            get
            {
                return _isSizeXFocused;
            }
            set
            {
                if (_isSizeXFocused == value)
                {
                    _isSizeXFocused = false;
                    RaisePropertyChanged("IsSizeXFocused");
                }
                _isSizeXFocused = value;
                RaisePropertyChanged("IsSizeXFocused");
            }
        }

        private bool _isSizeYFocused;
        public bool IsSizeYFocused
        {
            get
            {
                return _isSizeYFocused;
            }
            set
            {
                if (_isSizeYFocused == value)
                {
                    _isSizeYFocused = false;
                    RaisePropertyChanged("IsSizeYFocused");
                }
                _isSizeYFocused = value;
                RaisePropertyChanged("IsSizeYFocused");
            }
        }

        private bool _isMaxXFocused;
        public bool IsMaxXFocused
        {
            get
            {
                return _isMaxXFocused;
            }
            set
            {
                if (_isMaxXFocused == value)
                {
                    _isMaxXFocused = false;
                    RaisePropertyChanged("IsMaxXFocused");
                }
                _isMaxXFocused = value;
                RaisePropertyChanged("IsMaxXFocused");
            }
        }

        private bool _isMinXFocused;
        public bool IsMinXFocused
        {
            get
            {
                return _isMinXFocused;
            }
            set
            {
                if (_isMinXFocused == value)
                {
                    _isMinXFocused = false;
                    RaisePropertyChanged("IsMinXFocused");
                }
                _isMinXFocused = value;
                RaisePropertyChanged("IsMinXFocused");
            }
        }

        private bool _isMaxYFocused;
        public bool IsMaxYFocused
        {
            get
            {
                return _isMaxYFocused;
            }
            set
            {
                if (_isMaxYFocused == value)
                {
                    _isMaxYFocused = false;
                    RaisePropertyChanged("IsMaxYFocused");
                }
                _isMaxYFocused = value;
                RaisePropertyChanged("IsMaxYFocused");
            }
        }

        private bool _isMinYFocused;
        public bool IsMinYFocused
        {
            get
            {
                return _isMinYFocused;
            }
            set
            {
                if (_isMinYFocused == value)
                {
                    _isMinYFocused = false;
                    RaisePropertyChanged("IsMinYFocused");
                }
                _isMinYFocused = value;
                RaisePropertyChanged("IsMinYFocused");
            }
        }

        private bool _isGripWidthFocused;
        public bool IsGripWidthFocused
        {
            get
            {
                return _isGripWidthFocused;
            }
            set
            {
                if (_isGripWidthFocused == value)
                {
                    _isGripWidthFocused = false;
                    RaisePropertyChanged("IsGripWidthFocused");
                }
                _isGripWidthFocused = value;
                RaisePropertyChanged("IsGripWidthFocused");
            }
        }

        private bool _isTrimUpFocused;
        public bool IsTrimUpFocused
        {
            get
            {
                return _isTrimUpFocused;
            }
            set
            {
                if (_isTrimUpFocused == value)
                {
                    _isTrimUpFocused = false;
                    RaisePropertyChanged("IsTrimUpFocused");
                }
                _isTrimUpFocused = value;
                RaisePropertyChanged("IsTrimUpFocused");
            }
        }

        private bool _isTrimRightFocused;
        public bool IsTrimRightFocused
        {
            get
            {
                return _isTrimRightFocused;
            }
            set
            {
                if (_isTrimRightFocused == value)
                {
                    _isTrimRightFocused = false;
                    RaisePropertyChanged("IsTrimRightFocused");
                }
                _isTrimRightFocused = value;
                RaisePropertyChanged("IsTrimRightFocused");
            }
        }

        private bool _isTrimLeftFocused;
        public bool IsTrimLeftFocused
        {
            get
            {
                return _isTrimLeftFocused;
            }
            set
            {
                if (_isTrimLeftFocused == value)
                {
                    _isTrimLeftFocused = false;
                    RaisePropertyChanged("IsTrimLeftFocused");
                }
                _isTrimLeftFocused = value;
                RaisePropertyChanged("IsTrimLeftFocused");
            }
        }

        private bool _isStockQuantityFocused;
        public bool IsStockQuantityFocused
        {
            get
            {
                return _isStockQuantityFocused;
            }
            set
            {
                if (_isStockQuantityFocused == value)
                {
                    _isStockQuantityFocused = false;
                    RaisePropertyChanged("IsStockQuantityFocused");
                }
                _isStockQuantityFocused = value;
                RaisePropertyChanged("IsStockQuantityFocused");
            }
        }

        private decimal _selectedFontSize = 14;
        public decimal SelectedFontSize
        {
            get { return _selectedFontSize; }
            set { _selectedFontSize = value; OnPropertyChanged("selectedFontSize"); }
        }

        private ObservableCollection<SortOptionModel> _collectionOfListSortOptionModels;
        public ObservableCollection<SortOptionModel> CollectionOfListSortOptionModels
        {
            get { return _collectionOfListSortOptionModels; }
            set { _collectionOfListSortOptionModels = value; OnPropertyChanged("CollectionOfListSortOptionModels"); }
        }

        private SortOptionModel _selectedListSortOption;
        public SortOptionModel SelectedListSortOption
        {
            get { return _selectedListSortOption; }
            set
            {
                _selectedListSortOption = value;
                OnPropertyChanged("SelectedListSortOption");
            }
        }

        private ObservableCollection<SortOptionModel> _collectionOfSelectedSortOptionModels;
        public ObservableCollection<SortOptionModel> CollectionOfSelectedSortOptionModels
        {
            get { return _collectionOfSelectedSortOptionModels; }
            set { _collectionOfSelectedSortOptionModels = value; OnPropertyChanged("CollectionOfSelectedSortOptionModels"); }
        }

        private SortOptionModel _selectedSelectedSortOption;
        public SortOptionModel SelectedSelectedSortOption
        {
            get { return _selectedSelectedSortOption; }
            set
            {
                _selectedSelectedSortOption = value;
                OnPropertyChanged("SelectedSelectedSortOption");
            }
        }

        private ObservableCollection<SortOptionModel> _collectionOfListSortOptionModelsBackup;
        public ObservableCollection<SortOptionModel> CollectionOfListSortOptionModelsBackup
        {
            get { return _collectionOfListSortOptionModelsBackup; }
            set { _collectionOfListSortOptionModelsBackup = value; OnPropertyChanged("CollectionOfListSortOptionModelsBackup"); }
        }

        private ObservableCollection<SortOptionModel> _collectionOfSelectedSortOptionModelsBackup;
        public ObservableCollection<SortOptionModel> CollectionOfSelectedSortOptionModelsBackup
        {
            get { return _collectionOfSelectedSortOptionModelsBackup; }
            set { _collectionOfSelectedSortOptionModelsBackup = value; OnPropertyChanged("CollectionOfSelectedSortOptionModelsBackup"); }
        }

        private FontFamily _fontFamily = new FontFamily("Arial");
        public FontFamily FontFamily
        {
            get
            {
                return _fontFamily;
            }
            set
            {
                _fontFamily = value;
                OnPropertyChanged("fontFamily");
            }
        }

        private ObservableCollection<FilterOptionsModel> _collectionOfFilterOptionsModels = new ObservableCollection<FilterOptionsModel>();
        public ObservableCollection<FilterOptionsModel> CollectionOfFilterOptionsModels
        {
            get { return _collectionOfFilterOptionsModels; }
            set { _collectionOfFilterOptionsModels = value; OnPropertyChanged("CollectionOfFilterOptionsModels"); }
        }

        private ObservableCollection<FilterOptionsModel> _collectionOfFilterOptionsModelsBackup = new ObservableCollection<FilterOptionsModel>();
        public ObservableCollection<FilterOptionsModel> CollectionOfFilterOptionsModelsBackup
        {
            get { return _collectionOfFilterOptionsModelsBackup; }
            set { _collectionOfFilterOptionsModelsBackup = value; OnPropertyChanged("CollectionOfFilterOptionsModelsBackup"); }
        }

        //public CollectionViewSource BlankSheetCollectionViewSource { get; set; }

        //public ICollectionView BlankSheetCollection => BlankSheetCollectionViewSource.View;

        private bool? _isSelectAll;
        public bool? IsSelectAll
        {
            get { return _isSelectAll; }
            set
            {
                if (_isSelectAll != value)
                {
                    _isSelectAll = value;

                    SelectUnSelectAllCommand.Execute(value);

                    OnPropertyChanged("IsSelectAll");
                }
            }
        }

        private ObservableCollection<FilterOptionsModel> _testCollection;
        public ObservableCollection<FilterOptionsModel> TestCollection
        {
            get
            {
                _testCollection = CollectionOfFilterOptionsModels.Where(x => x.ColumnName == _columnName).ToObservableCollection();
                return _testCollection;
            }
            set { _testCollection = value; OnPropertyChanged("TestCollection"); }
        }

        private List<string> _listOfFilterColumns = new List<string>();
        public List<string> ListOfFilterColumns
        {
            get { return _listOfFilterColumns; }
            set { _listOfFilterColumns = value; OnPropertyChanged("ListOfFilterColumns"); }
        }

        public string ClearFilterColumnName => "Clear Filter from '" + _columnName + "'";

        public bool IsClearFilterButtonEnabled => ListOfFilterColumns.Contains(_columnName);

        private string _textSearch;
        public string TextSearch
        {
            get { return _textSearch; }
            set
            {
                _textSearch = value.ToLower();

                if (CollectionOfFilterOptionsModelsBackup.Count == 0)
                {
                    CollectionOfFilterOptionsModelsBackup = CollectionOfFilterOptionsModels;
                }

                if (_textSearch.Length > 2 && _textSearch.StartsWith("*") && _textSearch.EndsWith("*"))
                {
                    CollectionOfFilterOptionsModels = CollectionOfFilterOptionsModelsBackup
                        .Where(x => x.ColumnName == _columnName && x.Title.ToLower().Contains(_textSearch.Substring(1, _textSearch.Length - 2)))
                        .ToObservableCollection();
                }
                else if (_textSearch.Length > 1 && _textSearch.StartsWith("*"))
                {
                    CollectionOfFilterOptionsModels = CollectionOfFilterOptionsModelsBackup
                        .Where(x => x.ColumnName == _columnName && x.Title.ToLower().EndsWith(_textSearch.Substring(1, _textSearch.Length - 1)))
                        .ToObservableCollection();
                }
                else if (_textSearch.Length > 1 && _textSearch.EndsWith("*"))
                {
                    CollectionOfFilterOptionsModels = CollectionOfFilterOptionsModelsBackup
                        .Where(x => x.ColumnName == _columnName && x.Title.ToLower().StartsWith(_textSearch.Substring(0, _textSearch.Length - 1)))
                        .ToObservableCollection();
                }
                else
                {
                    CollectionOfFilterOptionsModels = CollectionOfFilterOptionsModelsBackup
                        .Where(x => x.ColumnName == _columnName && x.Title.ToLower().Contains(_textSearch))
                        .ToObservableCollection();
                }


                OnPropertyChanged("TestCollection");

                OnPropertyChanged("TextSearch");
            }
        }

        #endregion

        #region Mehods
        private BlankSheetModel GetCloneBlankSheetModel(BlankSheetModel pBlankSheetModel)
        {
            var blankSheetModel = new BlankSheetModel
            {
                IsAddOrEdit = "*",
                BlankSheetId = ListOfFilterColumns.Count == 0 ? CollectionOfBlankSheet.Max(x => x.BlankSheetId) + 1 : CollectionOfBlankSheetBackup.Max(x => x.BlankSheetId) + 1,
                BlankId = pBlankSheetModel.BlankId.Length > 7 ? pBlankSheetModel.BlankId.PadRight(15)
                    .Replace(pBlankSheetModel.BlankId.PadRight(15).Substring(8, 7), "-Copied") : pBlankSheetModel.BlankId + "-Copied",
                MatCode = pBlankSheetModel.MatCode,
                NewSizeX = pBlankSheetModel.NewSizeX ?? pBlankSheetModel.SelectedSizeX.SizeX,
                NewSizeY = pBlankSheetModel.NewSizeY ?? pBlankSheetModel.SelectedSizeY.SizeY,
                NewMaterial = pBlankSheetModel.NewMaterial ?? pBlankSheetModel.SelectedMaterial.MaterialName,
                NewThickness = pBlankSheetModel.NewThickness ?? pBlankSheetModel.SelectedThickness.ThicknessSmall,
                GripWidth = pBlankSheetModel.GripWidth,
                TrimUp = pBlankSheetModel.TrimUp,
                TrimRight = pBlankSheetModel.TrimRight,
                TrimLeft = pBlankSheetModel.TrimLeft,
                StockQuantity = pBlankSheetModel.StockQuantity,
                SortingCode = pBlankSheetModel.SortingCode,
                MaxX = pBlankSheetModel.MaxX,
                MinX = pBlankSheetModel.MinX,
                MaxY = pBlankSheetModel.MaxY,
                MinY = pBlankSheetModel.MinY
            };

            return blankSheetModel;
        }

        private BlankSheetModel GetGroupBlankSheetModel(BlankSheetModel pBlankSheetModel)
        {
            BlankSheetModel blankSheetModel = new BlankSheetModel
            {
                IsAddOrEdit = "*",
                //BlankSheetId = pBlankSheetModel.BlankSheetId,
                BlankId = pBlankSheetModel.BlankId,
                MatCode = pBlankSheetModel.MatCode,
                NewSizeX = pBlankSheetModel.NewSizeX ?? pBlankSheetModel.SelectedSizeX.SizeX,
                NewSizeY = pBlankSheetModel.NewSizeY ?? pBlankSheetModel.SelectedSizeY.SizeY,
                NewMaterial = pBlankSheetModel.NewMaterial ?? pBlankSheetModel.SelectedMaterial.MaterialName,
                NewThickness = pBlankSheetModel.NewThickness ?? pBlankSheetModel.SelectedThickness.ThicknessSmall,
                GripWidth = pBlankSheetModel.GripWidth,
                TrimUp = pBlankSheetModel.TrimUp,
                TrimRight = pBlankSheetModel.TrimRight,
                TrimLeft = pBlankSheetModel.TrimLeft,
                StockQuantity = pBlankSheetModel.StockQuantity,
                SortingCode = pBlankSheetModel.SortingCode,
                MaxX = pBlankSheetModel.MaxX,
                MinX = pBlankSheetModel.MinX,
                MaxY = pBlankSheetModel.MaxY,
                MinY = pBlankSheetModel.MinY
            };

            return blankSheetModel;
        }

        public bool SaveValidation()
        {
            if (IsGroupEdit)
            {
                if (_templistViewSorter != null)
                {
                    ObservableCollection<BlankSheetModel> selectedSheet = _templistViewSorter.SelectedItems.Cast<BlankSheetModel>().ToObservableCollection();

                    #region this is for Material
                    int numberNewMaterial;
                    bool resultNewMaterial = Int32.TryParse(SelectedGroupBlankSheet.NewMaterial, out numberNewMaterial);
                    if (selectedSheet.GroupBy(x => x.NewMaterial ?? x.SelectedMaterial.MaterialName).Count() == 1)//same value found
                    {
                        if (string.IsNullOrEmpty(SelectedGroupBlankSheet.NewMaterial) || (resultNewMaterial && numberNewMaterial == 0))
                        {
                            MessageBox.Show("Material should not be allowed with empty or '0' value!", "Material", MessageBoxButton.OK);
                            IsMaterialFocused = true;
                            return false;
                        }
                    }
                    else
                    {
                        if (resultNewMaterial && numberNewMaterial <= 0)
                        {
                            MessageBox.Show("Material should not be allowed with '0' value!", "Thickness", MessageBoxButton.OK);
                            IsThicknessFocused = true;
                            return false;
                        }
                    }
                    #endregion

                    #region this is for Thickness
                    if (selectedSheet.GroupBy(x => x.NewThickness ?? x.SelectedThickness.ThicknessSmall).Count() == 1)//same value found
                    {
                        if (SelectedGroupBlankSheet.NewThickness == null || SelectedGroupBlankSheet.NewThickness <= 0)
                        {
                            MessageBox.Show("Thickness should not be allowed with empty or '0' value!", "Thickness", MessageBoxButton.OK);
                            IsThicknessFocused = true;
                            return false;
                        }
                    }
                    else
                    {
                        if (SelectedGroupBlankSheet.NewThickness <= 0)
                        {
                            MessageBox.Show("Thickness should not be allowed with '0' value!", "Thickness", MessageBoxButton.OK);
                            IsThicknessFocused = true;
                            return false;
                        }
                    }
                    #endregion

                    #region this is for SizeX
                    if (selectedSheet.GroupBy(x => x.NewSizeX ?? x.SelectedSizeX.SizeX).Count() == 1)//same value found
                    {
                        if (SelectedGroupBlankSheet.NewSizeX == null || SelectedGroupBlankSheet.NewSizeX <= 0)
                        {
                            MessageBox.Show("X Size should not be allowed with empty or '0' value!", "X Size", MessageBoxButton.OK);
                            IsSizeXFocused = true;
                            return false;
                        }
                    }
                    else
                    {
                        if (SelectedGroupBlankSheet.NewSizeX <= 0)
                        {
                            MessageBox.Show("X Size should not be allowed '0' value!", "X Size", MessageBoxButton.OK);
                            IsSizeXFocused = true;
                            return false;
                        }
                    }
                    #endregion

                    #region this is for SizeY
                    if (selectedSheet.GroupBy(x => x.NewSizeY ?? x.SelectedSizeY.SizeY).Count() == 1)//same value found
                    {
                        if (SelectedGroupBlankSheet.NewSizeY == null || SelectedGroupBlankSheet.NewSizeY <= 0)
                        {
                            MessageBox.Show("Y Size should not be allowed with empty or '0' value!", "Y Size", MessageBoxButton.OK);
                            IsSizeYFocused = true;
                            return false;
                        }
                    }
                    else
                    {
                        if (SelectedGroupBlankSheet.NewSizeY <= 0)
                        {
                            MessageBox.Show("Y Size should not be allowed '0' value!", "Y Size", MessageBoxButton.OK);
                            IsSizeYFocused = true;
                            return false;
                        }
                    }
                    #endregion

                    #region this is for GripWidth
                    if (selectedSheet.GroupBy(x => x.GripWidth).Count() == 1)//same value found
                    {
                        if (SelectedGroupBlankSheet.GripWidth == null)
                        {
                            MessageBox.Show("Grip Width should not be allowed empty value!", "Grip Width", MessageBoxButton.OK);
                            IsGripWidthFocused = true;
                            return false;
                        }
                    }
                    #endregion

                    #region this is for TrimUp
                    if (selectedSheet.GroupBy(x => x.TrimUp).Count() == 1)//same value found
                    {
                        if (SelectedGroupBlankSheet.TrimUp == null)
                        {
                            MessageBox.Show("Trim Up should not be allowed empty value!", "Trim Up", MessageBoxButton.OK);
                            IsTrimUpFocused = true;
                            return false;
                        }
                    }
                    #endregion

                    #region this is for TrimRight
                    if (selectedSheet.GroupBy(x => x.TrimRight).Count() == 1)//same value found
                    {
                        if (SelectedGroupBlankSheet.TrimRight == null)
                        {
                            MessageBox.Show("Trim Right should not be allowed empty value!", "Trim Right", MessageBoxButton.OK);
                            IsTrimRightFocused = true;
                            return false;
                        }
                    }
                    #endregion

                    #region this is for TrimLeft
                    if (selectedSheet.GroupBy(x => x.TrimLeft).Count() == 1)//same value found
                    {
                        if (SelectedGroupBlankSheet.TrimLeft == null)
                        {
                            MessageBox.Show("Trim Left should not be allowed empty value!", "Trim Left", MessageBoxButton.OK);
                            IsTrimLeftFocused = true;
                            return false;
                        }
                    }
                    #endregion

                    #region this is for TrimLeft
                    if (selectedSheet.GroupBy(x => x.StockQuantity).Count() == 1)//same value found
                    {
                        if (SelectedGroupBlankSheet.StockQuantity == null)
                        {
                            MessageBox.Show("Stock Quantity should not be allowed empty value!", "Stock Quantity", MessageBoxButton.OK);
                            IsStockQuantityFocused = true;
                            return false;
                        }
                    }
                    #endregion

                    var firstOrDefault = selectedSheet.FirstOrDefault();
                    if (firstOrDefault?.MinX != null && selectedSheet.GroupBy(x => x.MinX).Count() == 1)
                    {
                        if (SelectedGroupBlankSheet.MinX == null)
                        {
                            MessageBox.Show("Min X should not be allowed empty value!", "Min X", MessageBoxButton.OK);
                            IsMinXFocused = true;
                            return false;
                        }
                    }

                    if (selectedSheet.FirstOrDefault().MinY != null && selectedSheet.GroupBy(x => x.MinY).Count() == 1)
                    {
                        if (SelectedGroupBlankSheet.MinY == null)
                        {
                            MessageBox.Show("Min Y should not be allowed empty value!", "Min Y", MessageBoxButton.OK);
                            IsMinYFocused = true;
                            return false;
                        }
                    }

                    if (selectedSheet.FirstOrDefault().MaxX != null && selectedSheet.GroupBy(x => x.MaxX).Count() == 1)
                    {
                        if (SelectedGroupBlankSheet.MaxX == null)
                        {
                            MessageBox.Show("Max X should not be allowed empty value!", "Max X", MessageBoxButton.OK);
                            IsMaxXFocused = true;
                            return false;
                        }
                        else
                        {
                            if (SelectedGroupBlankSheet.MaxX != null && SelectedGroupBlankSheet.MinX != null && SelectedGroupBlankSheet.MinX > SelectedGroupBlankSheet.MaxX)
                            {
                                MessageBox.Show("Please enter X Max value greater than or equal to X Min value!", "X Max", MessageBoxButton.OK);
                                IsMaxXFocused = true;
                                return false;
                            }

                            if (SelectedGroupBlankSheet.MaxX != null && SelectedGroupBlankSheet.MinX != null && SelectedGroupBlankSheet.MaxX > selectedSheet.Min(x => x.NewSizeX).Value)
                            {
                                MessageBox.Show("Please enter X Max value less than or equal to X Size value!", "X Max", MessageBoxButton.OK);
                                IsMaxXFocused = true;
                                return false;
                            }
                        }
                    }
                    else
                    {
                        if (SelectedGroupBlankSheet.MaxX != null && SelectedGroupBlankSheet.MinX == null)
                        {
                            MessageBox.Show("Please enter X Min value!", "X Min", MessageBoxButton.OK);
                            IsMinXFocused = true;
                            return false;
                        }

                        if (SelectedGroupBlankSheet.MaxX != null && SelectedGroupBlankSheet.MinX != null && SelectedGroupBlankSheet.MinX > SelectedGroupBlankSheet.MaxX)
                        {
                            MessageBox.Show("Please enter X Max value greater than or equal to X Min value!", "X Max", MessageBoxButton.OK);
                            IsMaxXFocused = true;
                            return false;
                        }

                        if (SelectedGroupBlankSheet.MaxX != null && SelectedGroupBlankSheet.MinX != null && SelectedGroupBlankSheet.MaxX > selectedSheet.Min(x => x.NewSizeX).Value)
                        {
                            MessageBox.Show("Please enter X Max value less than or equal to X Size value!", "X Max", MessageBoxButton.OK);
                            IsMaxXFocused = true;
                            return false;
                        }
                    }

                    if (selectedSheet.FirstOrDefault().MaxY != null && selectedSheet.GroupBy(x => x.MaxY).Count() == 1)
                    {
                        if (SelectedGroupBlankSheet.MaxY == null)
                        {
                            MessageBox.Show("Max Y should not be allowed empty value!", "Max Y", MessageBoxButton.OK);
                            IsMaxYFocused = true;
                            return false;
                        }
                        else
                        {
                            if (SelectedGroupBlankSheet.MaxY != null && SelectedGroupBlankSheet.MinY != null && SelectedGroupBlankSheet.MinY > SelectedGroupBlankSheet.MaxY)
                            {
                                MessageBox.Show("Please enter Y Max value greater than or equal to Y Min value!", "Y Max", MessageBoxButton.OK);
                                IsMaxYFocused = true;
                                return false;
                            }

                            if (SelectedGroupBlankSheet.MaxY != null && SelectedGroupBlankSheet.MinY != null && SelectedGroupBlankSheet.MaxY > selectedSheet.Min(x => x.NewSizeY).Value)
                            {
                                MessageBox.Show("Please enter Y Max value less than or equal to Y Size value!", "Y Max", MessageBoxButton.OK);
                                IsMaxYFocused = true;
                                return false;
                            }
                        }
                    }
                    else
                    {
                        if (SelectedGroupBlankSheet.MaxY != null && SelectedGroupBlankSheet.MinY == null)
                        {
                            MessageBox.Show("Please enter Y Min value!", "Y Min", MessageBoxButton.OK);
                            IsMinYFocused = true;
                            return false;
                        }

                        if (SelectedGroupBlankSheet.MaxY != null && SelectedGroupBlankSheet.MinY != null && SelectedGroupBlankSheet.MinY > SelectedGroupBlankSheet.MaxY)
                        {
                            MessageBox.Show("Please enter Y Max value greater than or equal to Y Min value!", "Y Max", MessageBoxButton.OK);
                            IsMaxYFocused = true;
                            return false;
                        }

                        if (SelectedGroupBlankSheet.MaxY != null && SelectedGroupBlankSheet.MinY != null && SelectedGroupBlankSheet.MaxY > selectedSheet.Min(x => x.NewSizeY).Value)
                        {
                            MessageBox.Show("Please enter Y Max value less than or equal to Y Size value!", "Y Max", MessageBoxButton.OK);
                            IsMaxYFocused = true;
                            return false;
                        }
                    }
                }
            }
            else
            {
                int numberBlankId;
                bool resultBlankId = Int32.TryParse(SelectedGroupBlankSheet.BlankId, out numberBlankId);

                if (string.IsNullOrEmpty(SelectedGroupBlankSheet.BlankId) || (resultBlankId && numberBlankId == 0))
                {
                    MessageBox.Show("Blank Id should not be allowed with empty or '0' value!", "Blank Id", MessageBoxButton.OK);
                    IsBlankIdFocused = true;
                    return false;
                }

                int numberNewMaterial;
                bool resultNewMaterial = Int32.TryParse(SelectedGroupBlankSheet.NewMaterial, out numberNewMaterial);

                if (string.IsNullOrEmpty(SelectedGroupBlankSheet.NewMaterial) || (resultNewMaterial && numberNewMaterial == 0))
                {
                    MessageBox.Show("Material should not be allowed with empty or '0' value!", "Material", MessageBoxButton.OK);
                    IsMaterialFocused = true;
                    return false;
                }

                if (SelectedGroupBlankSheet.NewThickness == null || SelectedGroupBlankSheet.NewThickness <= 0)
                {
                    MessageBox.Show("Thickness should not be allowed with empty or '0' value!", "Thickness", MessageBoxButton.OK);
                    IsThicknessFocused = true;
                    return false;
                }

                if (SelectedGroupBlankSheet.NewSizeX == null || SelectedGroupBlankSheet.NewSizeX <= 0)
                {
                    MessageBox.Show("X Size should not be allowed with empty or '0' value!", "X Size", MessageBoxButton.OK);
                    IsSizeXFocused = true;
                    return false;
                }

                if (SelectedGroupBlankSheet.NewSizeY == null || SelectedGroupBlankSheet.NewSizeY <= 0)
                {
                    MessageBox.Show("Y Size should not be allowed with empty or '0' value!", "Y Size", MessageBoxButton.OK);
                    IsSizeYFocused = true;
                    return false;
                }

                if (SelectedGroupBlankSheet.GripWidth == null || SelectedGroupBlankSheet.GripWidth < 0)
                {
                    MessageBox.Show("Grip Width should not be allowed with empty value!", "Grip Width", MessageBoxButton.OK);
                    IsGripWidthFocused = true;
                    return false;
                }

                if (SelectedGroupBlankSheet.TrimUp == null || SelectedGroupBlankSheet.TrimUp < 0)
                {
                    MessageBox.Show("Trim Up should not be allowed with empty value!", "Trim Up", MessageBoxButton.OK);
                    IsTrimUpFocused = true;
                    return false;
                }

                if (SelectedGroupBlankSheet.TrimRight == null || SelectedGroupBlankSheet.TrimRight < 0)
                {
                    MessageBox.Show("Trim Right should not be allowed with empty value!", "Trim Right", MessageBoxButton.OK);
                    IsTrimRightFocused = true;
                    return false;
                }

                if (SelectedGroupBlankSheet.TrimLeft == null || SelectedGroupBlankSheet.TrimLeft < 0)
                {
                    MessageBox.Show("Trim Left should not be allowed with empty value!", "Trim Left", MessageBoxButton.OK);
                    IsTrimLeftFocused = true;
                    return false;
                }

                if (SelectedGroupBlankSheet.StockQuantity == null || SelectedGroupBlankSheet.StockQuantity < 0)
                {
                    MessageBox.Show("Stock Quantity should not be allowed with empty value!", "Stock Quantity", MessageBoxButton.OK);
                    IsStockQuantityFocused = true;
                    return false;
                }


                if (SelectedGroupBlankSheet.MaxX == null && SelectedGroupBlankSheet.MinX != null)
                {
                    MessageBox.Show("Please enter X Max value!", "X Max", MessageBoxButton.OK);
                    IsMaxXFocused = true;
                    return false;
                }

                if (SelectedGroupBlankSheet.MaxX != null && SelectedGroupBlankSheet.MinX == null)
                {
                    MessageBox.Show("Please enter X Min value!", "X Min", MessageBoxButton.OK);
                    IsMinXFocused = true;
                    return false;
                }

                if (SelectedGroupBlankSheet.MaxX != null && SelectedGroupBlankSheet.MinX != null && SelectedGroupBlankSheet.MinX > SelectedGroupBlankSheet.MaxX)
                {
                    MessageBox.Show("Please enter X Max value greater than or equal to X Min value!", "X Max", MessageBoxButton.OK);
                    IsMaxXFocused = true;
                    return false;
                }

                if (SelectedGroupBlankSheet.MaxX != null && SelectedGroupBlankSheet.MinX != null && SelectedGroupBlankSheet.MaxX > SelectedGroupBlankSheet.NewSizeX)
                {
                    MessageBox.Show("Please enter X Max value less than or equal to X Size value!", "X Max", MessageBoxButton.OK);
                    IsMaxXFocused = true;
                    return false;
                }


                if (SelectedGroupBlankSheet.MaxY == null && SelectedGroupBlankSheet.MinY != null)
                {
                    MessageBox.Show("Please enter Y Max value!", "Y Max", MessageBoxButton.OK);
                    IsMaxYFocused = true;
                    return false;
                }

                if (SelectedGroupBlankSheet.MaxY != null && SelectedGroupBlankSheet.MinY == null)
                {
                    MessageBox.Show("Please enter Y Min value!", "Y Min", MessageBoxButton.OK);
                    IsMinYFocused = true;
                    return false;
                }

                if (SelectedGroupBlankSheet.MaxY != null && SelectedGroupBlankSheet.MinY != null && SelectedGroupBlankSheet.MinY > SelectedGroupBlankSheet.MaxY)
                {
                    MessageBox.Show("Please enter Y Max value greater than or equal to Y Min value!", "Y Max", MessageBoxButton.OK);
                    IsMaxYFocused = true;
                    return false;
                }

                if (SelectedGroupBlankSheet.MaxY != null && SelectedGroupBlankSheet.MinY != null && SelectedGroupBlankSheet.MaxY > SelectedGroupBlankSheet.NewSizeY)
                {
                    MessageBox.Show("Please enter Y Max value less than or equal to Y Size value!", "Y Max", MessageBoxButton.OK);
                    IsMaxYFocused = true;
                    return false;
                }


                if (SelectedGroupBlankSheet.StockQuantity == 0)
                {
                    if (MessageBox.Show("Stock Quantity is zero, do you want to continue ?", "Stock Quantity", MessageBoxButton.YesNo) == MessageBoxResult.No)
                        return false;
                }
            }

            return true;
        }

        //private bool CustomerFilter(object item)
        //{
        //    BlankSheetModel blankSheetModel = item as BlankSheetModel;
        //    if (blankSheetModel != null)
        //    {
        //        if (!string.IsNullOrEmpty(_columnName))
        //        {
        //            if (_columnName == "Blank ID")
        //            {
        //                return CollectionOfFilterOptionsModels.FirstOrDefault(
        //                           x => x.IsSelected && x.Title == blankSheetModel.BlankId) != null;
        //            }
        //        }
        //    }
        //    return true;
        //}

        public void RemoveFromFilterOptionsModels(BlankSheetModel pBlankSheetModel)
        {
            ObservableCollection<FilterOptionsModel> collectionOfFilterOptionsModelsForDelete = new ObservableCollection<FilterOptionsModel>();

            #region Blank ID
            if (CollectionOfBlankSheet.FirstOrDefault(x => x.BlankId == pBlankSheetModel.BlankId) == null)
            {
                collectionOfFilterOptionsModelsForDelete.Add(CollectionOfFilterOptionsModels.FirstOrDefault(x => x.Title == pBlankSheetModel.BlankId && x.ColumnName == "Blank ID"));
            }
            #endregion

            #region Material
            if (CollectionOfBlankSheet.FirstOrDefault(x => x.NewMaterial == pBlankSheetModel.NewMaterial) == null)
            {
                collectionOfFilterOptionsModelsForDelete.Add(CollectionOfFilterOptionsModels.FirstOrDefault(x => x.Title == pBlankSheetModel.NewMaterial && x.ColumnName == "Material"));
            }
            #endregion

            #region Thickness
            if (CollectionOfBlankSheet.FirstOrDefault(x => x.NewThickness.ToString() == pBlankSheetModel.NewThickness.ToString()) == null)
            {
                collectionOfFilterOptionsModelsForDelete.Add(CollectionOfFilterOptionsModels.FirstOrDefault(x => x.Title == pBlankSheetModel.NewThickness.ToString() && x.ColumnName == "Thickness"));
            }
            #endregion

            #region X Size
            if (CollectionOfBlankSheet.FirstOrDefault(x => x.NewSizeX.ToString() == pBlankSheetModel.NewSizeX.ToString()) == null)
            {
                collectionOfFilterOptionsModelsForDelete.Add(CollectionOfFilterOptionsModels.FirstOrDefault(x => x.Title == pBlankSheetModel.NewSizeX.ToString() && x.ColumnName == "X Size"));
            }
            #endregion

            #region Y Size
            if (CollectionOfBlankSheet.FirstOrDefault(x => x.NewSizeY.ToString() == pBlankSheetModel.NewSizeY.ToString()) == null)
            {
                collectionOfFilterOptionsModelsForDelete.Add(CollectionOfFilterOptionsModels.FirstOrDefault(x => x.Title == pBlankSheetModel.NewSizeY.ToString() && x.ColumnName == "Y Size"));
            }
            #endregion

            #region Grip Width
            if (CollectionOfBlankSheet.FirstOrDefault(x => x.GripWidth.ToString() == pBlankSheetModel.GripWidth.ToString()) == null)
            {
                collectionOfFilterOptionsModelsForDelete.Add(CollectionOfFilterOptionsModels.FirstOrDefault(x => x.Title == pBlankSheetModel.GripWidth.ToString() && x.ColumnName == "Grip Width"));
            }
            #endregion

            #region Trim (Up)
            if (CollectionOfBlankSheet.FirstOrDefault(x => x.TrimUp.ToString() == pBlankSheetModel.TrimUp.ToString()) == null)
            {
                collectionOfFilterOptionsModelsForDelete.Add(CollectionOfFilterOptionsModels.FirstOrDefault(x => x.Title == pBlankSheetModel.TrimUp.ToString() && x.ColumnName == "Trim (Up)"));
            }
            #endregion

            #region Trim (Right)
            if (CollectionOfBlankSheet.FirstOrDefault(x => x.TrimRight.ToString() == pBlankSheetModel.TrimRight.ToString()) == null)
            {
                collectionOfFilterOptionsModelsForDelete.Add(CollectionOfFilterOptionsModels.FirstOrDefault(x => x.Title == pBlankSheetModel.TrimRight.ToString() && x.ColumnName == "Trim (Right)"));
            }
            #endregion

            #region Trim (Left)
            if (CollectionOfBlankSheet.FirstOrDefault(x => x.TrimLeft.ToString() == pBlankSheetModel.TrimLeft.ToString()) == null)
            {
                collectionOfFilterOptionsModelsForDelete.Add(CollectionOfFilterOptionsModels.FirstOrDefault(x => x.Title == pBlankSheetModel.TrimLeft.ToString() && x.ColumnName == "Trim (Left)"));
            }
            #endregion

            #region Stock Quantity
            if (CollectionOfBlankSheet.FirstOrDefault(x => x.StockQuantity.ToString() == pBlankSheetModel.StockQuantity.ToString()) == null)
            {
                collectionOfFilterOptionsModelsForDelete.Add(CollectionOfFilterOptionsModels.FirstOrDefault(x => x.Title == pBlankSheetModel.StockQuantity.ToString() && x.ColumnName == "Stock Quantity"));
            }
            #endregion

            #region X Max
            if (CollectionOfBlankSheet.FirstOrDefault(x => x.MaxX.ToString() == pBlankSheetModel.MaxX.ToString()) == null)
            {
                collectionOfFilterOptionsModelsForDelete.Add(CollectionOfFilterOptionsModels.FirstOrDefault(x => x.Title == pBlankSheetModel.MaxX.ToString() && x.ColumnName == "X Max"));
            }
            #endregion

            #region X Min
            if (CollectionOfBlankSheet.FirstOrDefault(x => x.MinX.ToString() == pBlankSheetModel.MinX.ToString()) == null)
            {
                collectionOfFilterOptionsModelsForDelete.Add(CollectionOfFilterOptionsModels.FirstOrDefault(x => x.Title == pBlankSheetModel.MinX.ToString() && x.ColumnName == "X Min"));
            }
            #endregion

            #region Y Max
            if (CollectionOfBlankSheet.FirstOrDefault(x => x.MaxY.ToString() == pBlankSheetModel.MaxY.ToString()) == null)
            {
                collectionOfFilterOptionsModelsForDelete.Add(CollectionOfFilterOptionsModels.FirstOrDefault(x => x.Title == pBlankSheetModel.MaxY.ToString() && x.ColumnName == "Y Max"));
            }
            #endregion

            #region Y Min
            if (CollectionOfBlankSheet.FirstOrDefault(x => x.MinY.ToString() == pBlankSheetModel.MinY.ToString()) == null)
            {
                collectionOfFilterOptionsModelsForDelete.Add(CollectionOfFilterOptionsModels.FirstOrDefault(x => x.Title == pBlankSheetModel.MinY.ToString() && x.ColumnName == "Y Min"));
            }
            #endregion

            foreach (var item in collectionOfFilterOptionsModelsForDelete)
            {
                CollectionOfFilterOptionsModels.Remove(item);
            }
        }

        public void AddFromFilterOptionsModels(BlankSheetModel pBlankSheetModel)
        {
            #region Blank ID

            if (ListOfFilterColumns.Contains("Blank ID"))
            {
                if (CollectionOfFilterOptionsModels.FirstOrDefault(
                        x => x.Title == pBlankSheetModel.BlankId && x.ColumnName == "Blank ID") == null)
                {
                    FilterOptionsModel filterOptionsModel =
                        new FilterOptionsModel
                        {
                            Title = pBlankSheetModel.BlankId,
                            IsSelected = true,
                            ColumnName = "Blank ID"
                        };

                    CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                }
            }

            #endregion

            #region Material

            if (ListOfFilterColumns.Contains("Material"))
            {
                if (CollectionOfFilterOptionsModels.FirstOrDefault(
                        x => x.Title == pBlankSheetModel.NewMaterial && x.ColumnName == "Material") == null)
                {
                    FilterOptionsModel filterOptionsModel =
                        new FilterOptionsModel
                        {
                            Title = pBlankSheetModel.NewMaterial,
                            IsSelected = true,
                            ColumnName = "Material"
                        };

                    CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                }
            }

            #endregion

            #region Thickness

            if (ListOfFilterColumns.Contains("Thickness"))
            {
                if (CollectionOfFilterOptionsModels.FirstOrDefault(
                        x => x.Title == pBlankSheetModel.NewThickness.ToString() && x.ColumnName == "Thickness") ==
                    null)
                {
                    FilterOptionsModel filterOptionsModel =
                        new FilterOptionsModel
                        {
                            Title = pBlankSheetModel.NewThickness.ToString(),
                            IsSelected = true,
                            ColumnName = "Thickness"
                        };

                    CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                }
            }

            #endregion

            #region X Size

            if (ListOfFilterColumns.Contains("X Size"))
            {
                if (CollectionOfFilterOptionsModels.FirstOrDefault(
                        x => x.Title == pBlankSheetModel.NewSizeX.ToString() && x.ColumnName == "X Size") == null)
                {
                    FilterOptionsModel filterOptionsModel =
                        new FilterOptionsModel
                        {
                            Title = pBlankSheetModel.NewSizeX.ToString(),
                            IsSelected = true,
                            ColumnName = "X Size"
                        };

                    CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                }
            }

            #endregion

            #region Y Size

            if (ListOfFilterColumns.Contains("Y Size"))
            {
                if (CollectionOfFilterOptionsModels.FirstOrDefault(
                        x => x.Title == pBlankSheetModel.NewSizeY.ToString() && x.ColumnName == "Y Size") == null)
                {
                    FilterOptionsModel filterOptionsModel =
                        new FilterOptionsModel
                        {
                            Title = pBlankSheetModel.NewSizeY.ToString(),
                            IsSelected = true,
                            ColumnName = "Y Size"
                        };

                    CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                }
            }

            #endregion

            #region Grip Width

            if (ListOfFilterColumns.Contains("Grip Width"))
            {
                if (CollectionOfFilterOptionsModels.FirstOrDefault(
                        x => x.Title == pBlankSheetModel.GripWidth.ToString() && x.ColumnName == "Grip Width") == null)
                {
                    FilterOptionsModel filterOptionsModel =
                        new FilterOptionsModel
                        {
                            Title = pBlankSheetModel.GripWidth.ToString(),
                            IsSelected = true,
                            ColumnName = "Grip Width"
                        };

                    CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                }
            }

            #endregion

            #region Trim (Up)

            if (ListOfFilterColumns.Contains("Trim (Up)"))
            {
                if (CollectionOfFilterOptionsModels.FirstOrDefault(
                        x => x.Title == pBlankSheetModel.TrimUp.ToString() && x.ColumnName == "Trim (Up)") == null)
                {
                    FilterOptionsModel filterOptionsModel =
                        new FilterOptionsModel
                        {
                            Title = pBlankSheetModel.TrimUp.ToString(),
                            IsSelected = true,
                            ColumnName = "Trim (Up)"
                        };

                    CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                }
            }

            #endregion

            #region Trim (Right)

            if (ListOfFilterColumns.Contains("Trim (Right)"))
            {
                if (CollectionOfFilterOptionsModels.FirstOrDefault(
                        x => x.Title == pBlankSheetModel.TrimRight.ToString() && x.ColumnName == "Trim (Right)") ==
                    null)
                {
                    FilterOptionsModel filterOptionsModel =
                        new FilterOptionsModel
                        {
                            Title = pBlankSheetModel.TrimRight.ToString(),
                            IsSelected = true,
                            ColumnName = "Trim (Right)"
                        };

                    CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                }
            }

            #endregion

            #region Trim (Left)

            if (ListOfFilterColumns.Contains("Trim (Left)"))
            {
                if (CollectionOfFilterOptionsModels.FirstOrDefault(
                        x => x.Title == pBlankSheetModel.TrimLeft.ToString() && x.ColumnName == "Trim (Left)") == null)
                {
                    FilterOptionsModel filterOptionsModel =
                        new FilterOptionsModel
                        {
                            Title = pBlankSheetModel.TrimLeft.ToString(),
                            IsSelected = true,
                            ColumnName = "Trim (Left)"
                        };

                    CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                }
            }

            #endregion

            #region Stock Quantity

            if (ListOfFilterColumns.Contains("Stock Quantity"))
            {
                if (CollectionOfFilterOptionsModels.FirstOrDefault(
                        x => x.Title == pBlankSheetModel.StockQuantity.ToString() &&
                             x.ColumnName == "Stock Quantity") == null)
                {
                    FilterOptionsModel filterOptionsModel =
                        new FilterOptionsModel
                        {
                            Title = pBlankSheetModel.StockQuantity.ToString(),
                            IsSelected = true,
                            ColumnName = "Stock Quantity"
                        };

                    CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                }
            }

            #endregion

            #region X Max

            if (ListOfFilterColumns.Contains("X Max"))
            {
                if (CollectionOfFilterOptionsModels.FirstOrDefault(
                        x => x.Title == pBlankSheetModel.MaxX.ToString() && x.ColumnName == "X Max") == null)
                {
                    FilterOptionsModel filterOptionsModel =
                        new FilterOptionsModel
                        {
                            Title = pBlankSheetModel.MaxX.ToString(),
                            IsSelected = true,
                            ColumnName = "X Max"
                        };

                    CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                }
            }

            #endregion

            #region X Min

            if (ListOfFilterColumns.Contains("X Min"))
            {
                if (CollectionOfFilterOptionsModels.FirstOrDefault(
                        x => x.Title == pBlankSheetModel.MinX.ToString() && x.ColumnName == "X Min") == null)
                {
                    FilterOptionsModel filterOptionsModel =
                        new FilterOptionsModel
                        {
                            Title = pBlankSheetModel.MinX.ToString(),
                            IsSelected = true,
                            ColumnName = "X Min"
                        };

                    CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                }
            }

            #endregion

            #region Y Max

            if (ListOfFilterColumns.Contains("Y Max"))
            {
                if (CollectionOfFilterOptionsModels.FirstOrDefault(
                        x => x.Title == pBlankSheetModel.MaxY.ToString() && x.ColumnName == "Y Max") == null)
                {
                    FilterOptionsModel filterOptionsModel =
                        new FilterOptionsModel
                        {
                            Title = pBlankSheetModel.MaxY.ToString(),
                            IsSelected = true,
                            ColumnName = "Y Max"
                        };

                    CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                }
            }

            #endregion

            #region Y Min

            if (ListOfFilterColumns.Contains("Y Min"))
            {
                if (CollectionOfFilterOptionsModels.FirstOrDefault(
                        x => x.Title == pBlankSheetModel.MinY.ToString() && x.ColumnName == "Y Min") == null)
                {
                    FilterOptionsModel filterOptionsModel =
                        new FilterOptionsModel
                        {
                            Title = pBlankSheetModel.MinY.ToString(),
                            IsSelected = true,
                            ColumnName = "Y Min"
                        };

                    CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                }
            }

            #endregion
        }

        public void SetBackupOfSortOptions()
        {
            CollectionOfListSortOptionModelsBackup = new ObservableCollection<SortOptionModel>();
            foreach (var item in CollectionOfListSortOptionModels)
            {
                SortOptionModel sortOptionModel = new SortOptionModel
                {
                    Title = item.Title,
                    TitleNumber = item.TitleNumber,
                    ImageSource = item.ImageSource,
                    IsAscending = item.IsAscending,
                    PropertyName = item.PropertyName
                };

                CollectionOfListSortOptionModelsBackup.Add(sortOptionModel);
            }

            CollectionOfSelectedSortOptionModelsBackup = new ObservableCollection<SortOptionModel>();
            foreach (var item in CollectionOfSelectedSortOptionModels)
            {
                SortOptionModel sortOptionModel = new SortOptionModel
                {
                    Title = item.Title,
                    TitleNumber = item.TitleNumber,
                    ImageSource = item.ImageSource,
                    IsAscending = item.IsAscending,
                    PropertyName = item.PropertyName
                };

                CollectionOfSelectedSortOptionModelsBackup.Add(sortOptionModel);
            }
        }
        #endregion

        #region Commands
        #region Open Blank Sheet Registration Command
        private DelegateCommand _openBlankSheetRegistrationCommand;
        public ICommand OpenBlankSheetRegistrationCommand => _openBlankSheetRegistrationCommand ?? (_openBlankSheetRegistrationCommand =
                                                                 new DelegateCommand(OnOpenBlankSheetRegistrationCommand));

        private void OnOpenBlankSheetRegistrationCommand(object pName)
        {
            _templistViewSorter = pName as ListView;
            _blankSheetRegistrationWindow = new BlankSheetRegistrationWindow(true);
            SelectedGroupBlankSheet = new BlankSheetModel();
            _blankSheetRegistrationWindow.DataContext = this;
            _blankSheetRegistrationWindow.ShowDialog();
        }
        #endregion

        #region Save Blank Sheet Registration Command
        private DelegateCommand _saveBlankSheetRegistrationCommand;
        public ICommand SaveBlankSheetRegistrationCommand => _saveBlankSheetRegistrationCommand ?? (_saveBlankSheetRegistrationCommand =
                                                                 new DelegateCommand(OnSaveBlankSheetRegistrationCommand));

        private void OnSaveBlankSheetRegistrationCommand(object pName)
        {
            if (_blankSheetRegistrationWindow != null)
            {
                if (SaveValidation() != true)
                {
                    return;
                }

                if (_blankSheetRegistrationWindow.IsNewBlankSheet)
                {
                    SelectedGroupBlankSheet.IsAddOrEdit = "*";
                    SelectedGroupBlankSheet.BlankSheetId = ListOfFilterColumns.Count == 0
                        ? CollectionOfBlankSheet.Max(x => x.BlankSheetId) + 1
                        : CollectionOfBlankSheetBackup.Max(x => x.BlankSheetId) + 1;

                    CollectionOfBlankSheet.Add(SelectedGroupBlankSheet);

                    if (ListOfFilterColumns.Count != 0)
                    {
                        CollectionOfBlankSheetBackup.Add(SelectedGroupBlankSheet);
                        AddFromFilterOptionsModels(SelectedGroupBlankSheet);
                    }

                    _templistViewSorter.SelectedItems.Clear();
                    _templistViewSorter.Items.Refresh();
                }
                else
                {
                    foreach (var item in _templistViewSorter.SelectedItems)
                    {
                        BlankSheetModel blankSheetModel = item as BlankSheetModel;

                        blankSheetModel.IsGroupEdit = IsGroupEdit;

                        if (!string.IsNullOrEmpty(SelectedGroupBlankSheet.NewMaterial.Trim()))
                        {
                            blankSheetModel.NewMaterial = SelectedGroupBlankSheet.NewMaterial;
                        }

                        if (SelectedGroupBlankSheet.NewThickness != null && SelectedGroupBlankSheet.NewThickness > 0)
                        {
                            blankSheetModel.NewThickness = SelectedGroupBlankSheet.NewThickness;
                        }

                        if (SelectedGroupBlankSheet.NewSizeX != null && SelectedGroupBlankSheet.NewSizeX > 0)
                        {
                            blankSheetModel.NewSizeX = SelectedGroupBlankSheet.NewSizeX;
                        }

                        if (SelectedGroupBlankSheet.NewSizeY != null && SelectedGroupBlankSheet.NewSizeY > 0)
                        {
                            blankSheetModel.NewSizeY = SelectedGroupBlankSheet.NewSizeY;
                        }

                        if (SelectedGroupBlankSheet.GripWidth != null)
                        {
                            blankSheetModel.GripWidth = SelectedGroupBlankSheet.GripWidth;
                        }

                        if (SelectedGroupBlankSheet.TrimUp != null)
                        {
                            blankSheetModel.TrimUp = SelectedGroupBlankSheet.TrimUp;
                        }

                        if (SelectedGroupBlankSheet.TrimRight != null)
                        {
                            blankSheetModel.TrimRight = SelectedGroupBlankSheet.TrimRight;
                        }

                        if (SelectedGroupBlankSheet.TrimLeft != null)
                        {
                            blankSheetModel.TrimLeft = SelectedGroupBlankSheet.TrimLeft;
                        }

                        if (SelectedGroupBlankSheet.StockQuantity != null)
                        {
                            blankSheetModel.StockQuantity = SelectedGroupBlankSheet.StockQuantity;
                        }

                        if (SelectedGroupBlankSheet.MaxX != null)
                        {
                            blankSheetModel.MaxX = SelectedGroupBlankSheet.MaxX;
                        }

                        if (SelectedGroupBlankSheet.MinX != null)
                        {
                            blankSheetModel.MinX = SelectedGroupBlankSheet.MinX;
                        }

                        if (SelectedGroupBlankSheet.MaxY != null)
                        {
                            blankSheetModel.MaxY = SelectedGroupBlankSheet.MaxY;
                        }

                        if (SelectedGroupBlankSheet.MinY != null)
                        {
                            blankSheetModel.MinY = SelectedGroupBlankSheet.MinY;
                        }

                        blankSheetModel.IsGroupEdit = false;
                    }

                    _templistViewSorter.SelectedItems.Clear();
                    _templistViewSorter.Items.Refresh();
                    _templistViewSorter = null;
                }


                _blankSheetRegistrationWindow.Close();
                _blankSheetRegistrationWindow = null;
                SelectedGroupBlankSheet = new BlankSheetModel();

                IsGroupEdit = false;
            }
        }
        #endregion

        #region Delete Blank Sheet Registration Command
        private DelegateCommand _deleteBlankSheetRegistrationCommand;
        public ICommand DeleteBlankSheetRegistrationCommand => _deleteBlankSheetRegistrationCommand ?? (_deleteBlankSheetRegistrationCommand =
                                                                   new DelegateCommand(OnDeleteBlankSheetRegistrationCommand));

        private void OnDeleteBlankSheetRegistrationCommand(object pName)
        {
            ListView listViewSorter = pName as ListView;
            ObservableCollection<BlankSheetModel> collectionOfBlankForDelete = new ObservableCollection<BlankSheetModel>();
            if (listViewSorter != null)
            {
                foreach (var item in listViewSorter.SelectedItems)
                {
                    BlankSheetModel blankSheetModel = item as BlankSheetModel;
                    collectionOfBlankForDelete.Add(blankSheetModel);
                }

                foreach (var item in collectionOfBlankForDelete)
                {
                    CollectionOfBlankSheet.Remove(item);

                    if (ListOfFilterColumns.Count != 0)
                    {
                        CollectionOfBlankSheetBackup.Remove(item);

                        RemoveFromFilterOptionsModels(item);
                    }
                }

                listViewSorter.Items.Refresh();
            }
        }
        #endregion

        #region Reset Blank Sheet Registration Command
        private DelegateCommand _resetBlankSheetRegistrationCommand;
        public ICommand ResetBlankSheetRegistrationCommand => _resetBlankSheetRegistrationCommand ?? (_resetBlankSheetRegistrationCommand =
                                                                  new DelegateCommand(OnResetBlankSheetRegistrationCommand));

        private void OnResetBlankSheetRegistrationCommand(object pName)
        {
            ClearFilterFromAllColumnsCommand.Execute(null);

            CollectionOfBlankSheet = BlmRepository.GetAllBlankSheet();
        }
        #endregion

        #region Quit Application Command
        private DelegateCommand _quitApplicationCommand;
        public ICommand QuitApplicationCommand => _quitApplicationCommand ?? (_quitApplicationCommand =
                                                      new DelegateCommand(OnQuitApplicationCommand));

        private void OnQuitApplicationCommand(object pName)
        {
            Application.Current.MainWindow.Close();
        }
        #endregion

        #region Copy Paste Command
        private DelegateCommand _copyPasteCommand;
        public ICommand CopyPasteCommand => _copyPasteCommand ?? (_copyPasteCommand = new DelegateCommand(OnCopyPasteCommand));

        private void OnCopyPasteCommand(object pName)
        {
            ListView listViewSorter = pName as ListView;
            if (listViewSorter != null)
            {
                foreach (var item in listViewSorter.SelectedItems)
                {
                    BlankSheetModel blankSheetModel = item as BlankSheetModel;
                    CollectionOfBlankSheet.Insert(CollectionOfBlankSheet.IndexOf(blankSheetModel) + 1, (GetCloneBlankSheetModel(blankSheetModel)));

                    if (ListOfFilterColumns.Count != 0)
                    {
                        CollectionOfBlankSheetBackup.Add(CollectionOfBlankSheet.ElementAt(CollectionOfBlankSheet.IndexOf(blankSheetModel) + 1));
                        AddFromFilterOptionsModels(CollectionOfBlankSheet.ElementAt(CollectionOfBlankSheet.IndexOf(blankSheetModel) + 1));
                    }

                }

                listViewSorter.SelectedItems.Clear();

                listViewSorter.Items.Refresh();
            }
        }
        #endregion

        #region Save Blank Sheet Command
        private DelegateCommand _saveBlankSheetCommand;
        public ICommand SaveBlankSheetCommand => _saveBlankSheetCommand ?? (_saveBlankSheetCommand =
                                                     new DelegateCommand(OnSaveBlankSheetCommand));

        private void OnSaveBlankSheetCommand(object pName)
        {
            if (ListOfFilterColumns.Count == 0)
            {
                BlmRepository.SaveBlankSheet(CollectionOfBlankSheet);
            }
            else
            {
                var saveBlankSheet = new ObservableCollection<BlankSheetModel>();

                foreach (var item in CollectionOfBlankSheetBackup)
                {
                    saveBlankSheet.Add(
                        CollectionOfBlankSheet.FirstOrDefault(x => x.BlankSheetId == item.BlankSheetId) != null
                            ? CollectionOfBlankSheet.FirstOrDefault(x => x.BlankSheetId == item.BlankSheetId)
                            : item);
                }

                foreach (var item in CollectionOfBlankSheet.Where(x => CollectionOfBlankSheetBackup.All(y => y.BlankSheetId != x.BlankSheetId)))
                {
                    saveBlankSheet.Add(item);
                }

                BlmRepository.SaveBlankSheet(saveBlankSheet);
            }

            foreach (var item in CollectionOfBlankSheet)
            {
                item.IsAddOrEdit = "";
            }

            if (pName != null && pName.ToString() == "SaveAndExit")
            {
                Application.Current.MainWindow.Close();
            }

        }
        #endregion

        #region Group Edit Blank Sheet Command
        private DelegateCommand _groupEditBlankSheetCommand;
        public ICommand GroupEditBlankSheetCommand => _groupEditBlankSheetCommand ?? (_groupEditBlankSheetCommand =
                                                          new DelegateCommand(OnGroupEditBlankSheetCommand));

        ListView _templistViewSorter = new ListView();
        private void OnGroupEditBlankSheetCommand(object pName)
        {
            SelectedGroupBlankSheet = new BlankSheetModel();
            _templistViewSorter = pName as ListView;
            ObservableCollection<BlankSheetModel> tempCollectionOfBlankSheet = new ObservableCollection<BlankSheetModel>();

            if (_templistViewSorter != null)
                foreach (var item in _templistViewSorter.SelectedItems)
                {
                    BlankSheetModel blankSheetModel = item as BlankSheetModel;
                    tempCollectionOfBlankSheet.Add(GetGroupBlankSheetModel(blankSheetModel));
                }

            int countItemInCollection = tempCollectionOfBlankSheet.Count - 1;

            SelectedGroupBlankSheet.NewMaterial = tempCollectionOfBlankSheet.GroupBy(n => n.NewMaterial).Any(c => c.Count() > countItemInCollection) ? tempCollectionOfBlankSheet.FirstOrDefault()?.NewMaterial : "";
            SelectedGroupBlankSheet.NewThickness = tempCollectionOfBlankSheet.GroupBy(n => n.NewThickness).Any(c => c.Count() > countItemInCollection) ? tempCollectionOfBlankSheet.FirstOrDefault()?.NewThickness : null;
            SelectedGroupBlankSheet.NewSizeX = tempCollectionOfBlankSheet.GroupBy(n => n.NewSizeX).Any(c => c.Count() > countItemInCollection) ? tempCollectionOfBlankSheet.FirstOrDefault()?.NewSizeX : null;
            SelectedGroupBlankSheet.NewSizeY = tempCollectionOfBlankSheet.GroupBy(n => n.NewSizeY).Any(c => c.Count() > countItemInCollection) ? tempCollectionOfBlankSheet.FirstOrDefault()?.NewSizeY : null;
            SelectedGroupBlankSheet.GripWidth = tempCollectionOfBlankSheet.GroupBy(n => n.GripWidth).Any(c => c.Count() > countItemInCollection) ? tempCollectionOfBlankSheet.FirstOrDefault()?.GripWidth : null;
            SelectedGroupBlankSheet.TrimUp = tempCollectionOfBlankSheet.GroupBy(n => n.TrimUp).Any(c => c.Count() > countItemInCollection) ? tempCollectionOfBlankSheet.FirstOrDefault()?.TrimUp : null;
            SelectedGroupBlankSheet.TrimRight = tempCollectionOfBlankSheet.GroupBy(n => n.TrimRight).Any(c => c.Count() > countItemInCollection) ? tempCollectionOfBlankSheet.FirstOrDefault()?.TrimRight : null;
            SelectedGroupBlankSheet.TrimLeft = tempCollectionOfBlankSheet.GroupBy(n => n.TrimLeft).Any(c => c.Count() > countItemInCollection) ? tempCollectionOfBlankSheet.FirstOrDefault()?.TrimLeft : null;
            SelectedGroupBlankSheet.StockQuantity = tempCollectionOfBlankSheet.GroupBy(n => n.StockQuantity).Any(c => c.Count() > countItemInCollection) ? tempCollectionOfBlankSheet.FirstOrDefault()?.StockQuantity : null;
            SelectedGroupBlankSheet.MaxX = tempCollectionOfBlankSheet.GroupBy(n => n.MaxX).Any(c => c.Count() > countItemInCollection) ? tempCollectionOfBlankSheet.FirstOrDefault()?.MaxX : null;
            SelectedGroupBlankSheet.MinX = tempCollectionOfBlankSheet.GroupBy(n => n.MinX).Any(c => c.Count() > countItemInCollection) ? tempCollectionOfBlankSheet.FirstOrDefault()?.MinX : null;
            SelectedGroupBlankSheet.MaxY = tempCollectionOfBlankSheet.GroupBy(n => n.MaxY).Any(c => c.Count() > countItemInCollection) ? tempCollectionOfBlankSheet.FirstOrDefault()?.MaxY : null;
            SelectedGroupBlankSheet.MinY = tempCollectionOfBlankSheet.GroupBy(n => n.MinY).Any(c => c.Count() > countItemInCollection) ? tempCollectionOfBlankSheet.FirstOrDefault()?.MinY : null;

            IsGroupEdit = true;

            _blankSheetRegistrationWindow = new BlankSheetRegistrationWindow(false) { DataContext = this };
            _blankSheetRegistrationWindow.ShowDialog();
        }
        #endregion

        #region Increase font size Command
        private DelegateCommand _increaseFontSizeCommand;
        public ICommand IncreaseFontSizeCommand => _increaseFontSizeCommand ?? (_increaseFontSizeCommand =
                                                                 new DelegateCommand(OnIncreaseFontSizeCommand));

        private void OnIncreaseFontSizeCommand(object pName)
        {
            if (SelectedFontSize < 14)
            {
                SelectedFontSize++;
            }
            else if (SelectedFontSize >= 14 && SelectedFontSize < 28)
            {
                SelectedFontSize += 2;
            }
            else if (SelectedFontSize == 28)
            {
                SelectedFontSize = 36;
            }
            else if (SelectedFontSize == 36)
            {
                SelectedFontSize = 48;
            }
            else if (SelectedFontSize == 48)
            {
                SelectedFontSize = 72;
            }
            else if (SelectedFontSize == 72)
            {
                SelectedFontSize = 80;
            }
            else if (SelectedFontSize >= 80)
            {
                SelectedFontSize += 10;
            }
        }
        #endregion

        #region Decrease font size Command
        private DelegateCommand _decreaseFontSizeCommand;
        public ICommand DecreaseFontSizeCommand => _decreaseFontSizeCommand ?? (_decreaseFontSizeCommand =
                                                       new DelegateCommand(OnDecreaseFontSizeCommand));

        private void OnDecreaseFontSizeCommand(object pName)
        {
            if (SelectedFontSize <= 14)
            {
                SelectedFontSize--;
            }
            else if (SelectedFontSize > 14 && SelectedFontSize <= 28)
            {
                SelectedFontSize -= 2;
            }
            else if (SelectedFontSize == 36)
            {
                SelectedFontSize = 28;
            }
            else if (SelectedFontSize == 48)
            {
                SelectedFontSize = 36;
            }
            else if (SelectedFontSize == 72)
            {
                SelectedFontSize = 48;
            }
            else if (SelectedFontSize == 80)
            {
                SelectedFontSize = 72;
            }
            else if (SelectedFontSize > 80)
            {
                SelectedFontSize -= 10;
            }
        }
        #endregion

        #region Open Sort Options Command
        private DelegateCommand _openSortOptionsCommand;
        public ICommand OpenSortOptionsCommand => _openSortOptionsCommand ?? (_openSortOptionsCommand =
                                                                 new DelegateCommand(OnOpenSortOptionsCommand));

        private void OnOpenSortOptionsCommand(object pName)
        {
            SetBackupOfSortOptions();
            _sortOptions = new SortOptions { DataContext = this };
            _sortOptions.ShowDialog();
        }
        #endregion

        ListBox _listBoxSelected = new ListBox();
        ListBox _listBoxLis = new ListBox();
        #region Move To Selected Up Command
        private DelegateCommand _moveToSelectedUpCommand;
        public ICommand MoveToSelectedUpCommand => _moveToSelectedUpCommand ?? (_moveToSelectedUpCommand =
                                                      new DelegateCommand(OnMoveToSelectedUpCommand, CanMoveToSelectedUp));

        private bool CanMoveToSelectedUp(object pName)
        {
            if (SelectedListSortOption != null && string.IsNullOrEmpty(SelectedListSortOption.Title))
            {
                return false;
            }

            return SelectedListSortOption != null;
        }

        private void OnMoveToSelectedUpCommand(object pName)
        {
            _listBoxSelected = pName as ListBox;

            foreach (var item in CollectionOfSelectedSortOptionModels)
            {
                if (string.IsNullOrEmpty(item.Title))
                {
                    item.Title = SelectedListSortOption.Title;
                    item.TitleNumber = SelectedListSortOption.TitleNumber;
                    item.ImageSource = "/BLM;component/Resources/Images/up.png";
                    item.IsAscending = true;
                    item.PropertyName = SelectedListSortOption.PropertyName;

                    SelectedListSortOption.Title = "";

                    if (_listBoxSelected != null)
                    {
                        _listBoxSelected.SelectedItem = null;
                        _listBoxSelected.Items.Refresh();
                    }

                    if (_listBoxLis != null)
                    {
                        _listBoxLis.SelectedItem = null;
                        _listBoxLis.Items.Refresh();
                    }

                    return;
                }
            }
        }
        #endregion

        #region Move To Selected Down Command
        private DelegateCommand _moveToSelectedDownCommand;
        public ICommand MoveToSelectedDownCommand => _moveToSelectedDownCommand ?? (_moveToSelectedDownCommand =
                                                       new DelegateCommand(OnMoveToSelectedDownCommand, CanMoveToSelectedDown));

        private bool CanMoveToSelectedDown(object pName)
        {
            if (SelectedListSortOption != null && string.IsNullOrEmpty(SelectedListSortOption.Title))
            {
                return false;
            }

            return SelectedListSortOption != null;
        }

        private void OnMoveToSelectedDownCommand(object pName)
        {
            _listBoxSelected = pName as ListBox;

            foreach (var item in CollectionOfSelectedSortOptionModels)
            {
                if (string.IsNullOrEmpty(item.Title))
                {
                    item.Title = SelectedListSortOption.Title;
                    item.TitleNumber = SelectedListSortOption.TitleNumber;
                    item.ImageSource = "/BLM;component/Resources/Images/down.png";
                    item.IsAscending = false;
                    item.PropertyName = SelectedListSortOption.PropertyName;

                    SelectedListSortOption.Title = "";

                    if (_listBoxSelected != null)
                    {
                        _listBoxSelected.SelectedItem = null;
                        _listBoxSelected.Items.Refresh();
                    }

                    if (_listBoxLis != null)
                    {
                        _listBoxLis.SelectedItem = null;
                        _listBoxLis.Items.Refresh();
                    }

                    return;
                }
            }
        }
        #endregion

        #region Move To List Command
        private DelegateCommand _moveToListCommand;
        public ICommand MoveToListCommand => _moveToListCommand ?? (_moveToListCommand =
                                                     new DelegateCommand(OnMoveToListCommand, CanMoveToList));

        private bool CanMoveToList(object pName)
        {
            if (SelectedSelectedSortOption != null && string.IsNullOrEmpty(SelectedSelectedSortOption.Title))
            {
                return false;
            }

            return SelectedSelectedSortOption != null;
        }

        private void OnMoveToListCommand(object pName)
        {
            _listBoxLis = pName as ListBox;

            var item = CollectionOfListSortOptionModels
                .FirstOrDefault(x => x.TitleNumber == SelectedSelectedSortOption.TitleNumber);
            if (item != null)
            {
                item.Title = SelectedSelectedSortOption.Title;
                item.TitleNumber = SelectedSelectedSortOption.TitleNumber;
                item.ImageSource = "";
                item.PropertyName = SelectedSelectedSortOption.PropertyName;
            }
            SelectedSelectedSortOption.Title = "";
            SelectedSelectedSortOption.ImageSource = "";

            CollectionOfSelectedSortOptionModels = CollectionOfSelectedSortOptionModels.OrderBy(x => x.Title == "").ToObservableCollection();

            if (_listBoxLis != null)
            {
                _listBoxLis.SelectedItem = null;
                _listBoxLis.Items.Refresh();
            }

            if (_listBoxSelected != null)
            {
                _listBoxSelected.SelectedItem = null;
                _listBoxSelected.Items.Refresh();
            }
        }
        #endregion

        #region Sort Option Apply Command
        private DelegateCommand _sortOptionApplyCommand;
        public ICommand SortOptionApplyCommand => _sortOptionApplyCommand ?? (_sortOptionApplyCommand =
                                                      new DelegateCommand(OnSortOptionApplyCommand));

        private void OnSortOptionApplyCommand(object pName)
        {
            int counter = 0;
            SortDescription sortDescription1 = new SortDescription();
            SortDescription sortDescription2 = new SortDescription();
            SortDescription sortDescription3 = new SortDescription();
            SortDescription sortDescription4 = new SortDescription();
            SortDescription sortDescription5 = new SortDescription();
            foreach (var item in CollectionOfSelectedSortOptionModels)
            {
                if (string.IsNullOrEmpty(item.Title)) continue;
                if (counter == 0)
                {
                    sortDescription1 = item.IsAscending ? new SortDescription(item.PropertyName, ListSortDirection.Ascending) : new SortDescription(item.PropertyName, ListSortDirection.Descending);
                }

                if (counter == 1)
                {
                    sortDescription2 = item.IsAscending ? new SortDescription(item.PropertyName, ListSortDirection.Ascending) : new SortDescription(item.PropertyName, ListSortDirection.Descending);
                }

                if (counter == 2)
                {
                    sortDescription3 = item.IsAscending ? new SortDescription(item.PropertyName, ListSortDirection.Ascending) : new SortDescription(item.PropertyName, ListSortDirection.Descending);
                }

                if (counter == 3)
                {
                    sortDescription4 = item.IsAscending ? new SortDescription(item.PropertyName, ListSortDirection.Ascending) : new SortDescription(item.PropertyName, ListSortDirection.Descending);
                }

                if (counter == 4)
                {
                    sortDescription5 = item.IsAscending ? new SortDescription(item.PropertyName, ListSortDirection.Ascending) : new SortDescription(item.PropertyName, ListSortDirection.Descending);
                }

                counter++;
            }

            if (counter > 0)
            {
                CollectionOfBlankSheet = CollectionOfBlankSheet.BuildOrderBys(
                        sortDescription1,
                        sortDescription2,
                        sortDescription3,
                        sortDescription4,
                        sortDescription5
                    )
                    .ToObservableCollection();
            }

            SetBackupOfSortOptions();

            _sortOptions?.Close();
        }
        #endregion

        #region Cancel Sort Command
        private DelegateCommand _cancelSortCommand;
        public ICommand CancelSortCommand => _cancelSortCommand ?? (_cancelSortCommand =
                                                   new DelegateCommand(OnCancelSortCommandCommand));

        private void OnCancelSortCommandCommand(object pName)
        {
            CollectionOfListSortOptionModels = new ObservableCollection<SortOptionModel>(CollectionOfListSortOptionModelsBackup);
            CollectionOfSelectedSortOptionModels = new ObservableCollection<SortOptionModel>(CollectionOfSelectedSortOptionModelsBackup);
        }
        #endregion

        #region Open Filter Options Command
        private DelegateCommand _openFilterOptionsCommand;
        public ICommand OpenFilterOptionsCommand => _openFilterOptionsCommand ?? (_openFilterOptionsCommand =
                                                      new DelegateCommand(OnOpenFilterOptionsCommand));

        private void OnOpenFilterOptionsCommand(object pName)
        {
            var mouseButtonEventArgs = pName as MouseButtonEventArgs;

            var gridViewColumnHeader = mouseButtonEventArgs?.Source as GridViewColumnHeader;
            if (gridViewColumnHeader != null)
            {
                _columnName = gridViewColumnHeader.Tag.ToString();
            }

            var textBlock = mouseButtonEventArgs?.Source as TextBlock;
            if (textBlock != null)
            {
                _columnName = textBlock.Tag.ToString();
            }

            var image = mouseButtonEventArgs?.Source as Image;
            if (image != null)
            {
                _columnName = image.Tag.ToString();
            }

            //CollectionOfFilterOptionsModels = new ObservableCollection<FilterOptionsModel>();

            //var filteredItems = BlankSheetCollection.Cast<BlankSheetModel>().ToObservableCollection();

            if (!string.IsNullOrEmpty(_columnName))
            {
                if (CollectionOfBlankSheetBackup.Count == 0)
                {
                    CollectionOfBlankSheetBackup = new ObservableCollection<BlankSheetModel>(CollectionOfBlankSheet);
                }

                if (CollectionOfFilterOptionsModels.FirstOrDefault(x => x.ColumnName == _columnName) == null)
                {
                    #region Blank ID
                    if (_columnName == "Blank ID")
                    {
                        foreach (var item in CollectionOfBlankSheet
                            .Where(x => !string.IsNullOrEmpty(x.BlankId)).OrderBy(y => y.BlankId)
                            .Select(o => o.BlankId)
                            .Distinct())
                        {
                            FilterOptionsModel filterOptionsModel =
                                new FilterOptionsModel
                                {
                                    Title = item,
                                    IsSelected = CollectionOfBlankSheet.Any(x => x.BlankId == item),
                                    ColumnName = _columnName
                                };

                            CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                        }
                    }
                    #endregion

                    #region Material
                    if (_columnName == "Material")
                    {
                        foreach (var item in CollectionOfBlankSheet.Where(x => !string.IsNullOrEmpty(x.NewMaterial)).OrderBy(y => y.NewMaterial)
                            .Select(o => o.NewMaterial)
                            .Distinct())
                        {
                            FilterOptionsModel filterOptionsModel =
                                new FilterOptionsModel
                                {
                                    Title = item,
                                    IsSelected = CollectionOfBlankSheet.Any(x => x.NewMaterial == item),
                                    ColumnName = _columnName
                                };

                            CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                        }
                    }
                    #endregion

                    #region Thickness
                    if (_columnName == "Thickness")
                    {
                        foreach (var item in CollectionOfBlankSheet.Where(x => x.NewThickness != null).OrderBy(y => y.NewThickness)
                            .Select(o => o.NewThickness)
                            .Distinct())
                        {
                            FilterOptionsModel filterOptionsModel =
                                new FilterOptionsModel
                                {
                                    Title = item.ToString(),
                                    IsSelected = CollectionOfBlankSheet.Any(x => x.NewThickness.ToString() == item.ToString()),
                                    ColumnName = _columnName
                                };

                            CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                        }
                    }
                    #endregion

                    #region X Size
                    if (_columnName == "X Size")
                    {
                        foreach (var item in CollectionOfBlankSheet.Where(x => x.NewSizeX != null).OrderBy(y => y.NewSizeX)
                            .Select(o => o.NewSizeX)
                            .Distinct())
                        {
                            FilterOptionsModel filterOptionsModel =
                                new FilterOptionsModel
                                {
                                    Title = item.ToString(),
                                    IsSelected = CollectionOfBlankSheet.Any(x => x.NewSizeX.ToString() == item.ToString()),
                                    ColumnName = _columnName
                                };

                            CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                        }
                    }
                    #endregion

                    #region Y Size
                    if (_columnName == "Y Size")
                    {
                        foreach (var item in CollectionOfBlankSheet.Where(x => x.NewSizeY != null).OrderBy(y => y.NewSizeY)
                            .Select(o => o.NewSizeY)
                            .Distinct())
                        {
                            FilterOptionsModel filterOptionsModel =
                                new FilterOptionsModel
                                {
                                    Title = item.ToString(),
                                    IsSelected = CollectionOfBlankSheet.Any(x => x.NewSizeY.ToString() == item.ToString()),
                                    ColumnName = _columnName
                                };

                            CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                        }
                    }
                    #endregion

                    #region Grip Width
                    if (_columnName == "Grip Width")
                    {
                        foreach (var item in CollectionOfBlankSheet.Where(x => x.GripWidth != null).OrderBy(y => y.GripWidth)
                            .Select(o => o.GripWidth)
                            .Distinct())
                        {
                            FilterOptionsModel filterOptionsModel =
                                new FilterOptionsModel
                                {
                                    Title = item.ToString(),
                                    IsSelected = CollectionOfBlankSheet.Any(x => x.GripWidth.ToString() == item.ToString()),
                                    ColumnName = _columnName
                                };

                            CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                        }
                    }
                    #endregion

                    #region Trim (Up)
                    if (_columnName == "Trim (Up)")
                    {
                        foreach (var item in CollectionOfBlankSheet.Where(x => x.TrimUp != null).OrderBy(y => y.TrimUp)
                            .Select(o => o.TrimUp)
                            .Distinct())
                        {
                            FilterOptionsModel filterOptionsModel =
                                new FilterOptionsModel
                                {
                                    Title = item.ToString(),
                                    IsSelected = CollectionOfBlankSheet.Any(x => x.TrimUp.ToString() == item.ToString()),
                                    ColumnName = _columnName
                                };

                            CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                        }
                    }
                    #endregion

                    #region Trim (Right)
                    if (_columnName == "Trim (Right)")
                    {
                        foreach (var item in CollectionOfBlankSheet.Where(x => x.TrimRight != null).OrderBy(y => y.TrimRight)
                            .Select(o => o.TrimRight)
                            .Distinct())
                        {
                            FilterOptionsModel filterOptionsModel =
                                new FilterOptionsModel
                                {
                                    Title = item.ToString(),
                                    IsSelected = CollectionOfBlankSheet.Any(x => x.TrimRight.ToString() == item.ToString()),
                                    ColumnName = _columnName
                                };

                            CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                        }
                    }
                    #endregion

                    #region Trim (Left)
                    if (_columnName == "Trim (Left)")
                    {
                        foreach (var item in CollectionOfBlankSheet.Where(x => x.TrimLeft != null).OrderBy(y => y.TrimLeft)
                            .Select(o => o.TrimLeft)
                            .Distinct())
                        {
                            FilterOptionsModel filterOptionsModel =
                                new FilterOptionsModel
                                {
                                    Title = item.ToString(),
                                    IsSelected = CollectionOfBlankSheet.Any(x => x.TrimLeft.ToString() == item.ToString()),
                                    ColumnName = _columnName
                                };

                            CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                        }
                    }
                    #endregion

                    #region Stock Quantity
                    if (_columnName == "Stock Quantity")
                    {
                        foreach (var item in CollectionOfBlankSheet.Where(x => x.StockQuantity != null).OrderBy(y => y.StockQuantity)
                            .Select(o => o.StockQuantity)
                            .Distinct())
                        {
                            FilterOptionsModel filterOptionsModel =
                                new FilterOptionsModel
                                {
                                    Title = item.ToString(),
                                    IsSelected = CollectionOfBlankSheet.Any(x => x.StockQuantity.ToString() == item.ToString()),
                                    ColumnName = _columnName
                                };

                            CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                        }
                    }
                    #endregion

                    #region X Max
                    if (_columnName == "X Max")
                    {
                        foreach (var item in CollectionOfBlankSheet.Where(x => x.MaxX != null).OrderBy(y => y.MaxX)
                            .Select(o => o.MaxX)
                            .Distinct())
                        {
                            FilterOptionsModel filterOptionsModel =
                                new FilterOptionsModel
                                {
                                    Title = item.ToString(),
                                    IsSelected = CollectionOfBlankSheet.Any(x => x.MaxX.ToString() == item.ToString()),
                                    ColumnName = _columnName
                                };

                            CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                        }
                    }
                    #endregion

                    #region X Min
                    if (_columnName == "X Min")
                    {
                        foreach (var item in CollectionOfBlankSheet.Where(x => x.MinX != null).OrderBy(y => y.MinX)
                            .Select(o => o.MinX)
                            .Distinct())
                        {
                            FilterOptionsModel filterOptionsModel =
                                new FilterOptionsModel
                                {
                                    Title = item.ToString(),
                                    IsSelected = CollectionOfBlankSheet.Any(x => x.MinX.ToString() == item.ToString()),
                                    ColumnName = _columnName
                                };

                            CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                        }
                    }
                    #endregion

                    #region Y Max
                    if (_columnName == "Y Max")
                    {
                        foreach (var item in CollectionOfBlankSheet.Where(x => x.MaxY != null).OrderBy(y => y.MaxY)
                            .Select(o => o.MaxY)
                            .Distinct())
                        {
                            FilterOptionsModel filterOptionsModel =
                                new FilterOptionsModel
                                {
                                    Title = item.ToString(),
                                    IsSelected = CollectionOfBlankSheet.Any(x => x.MaxY.ToString() == item.ToString()),
                                    ColumnName = _columnName
                                };

                            CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                        }
                    }
                    #endregion

                    #region Y Min
                    if (_columnName == "Y Min")
                    {
                        foreach (var item in CollectionOfBlankSheet.Where(x => x.MinY != null).OrderBy(y => y.MinY)
                            .Select(o => o.MinY)
                            .Distinct())
                        {
                            FilterOptionsModel filterOptionsModel =
                                new FilterOptionsModel
                                {
                                    Title = item.ToString(),
                                    IsSelected = CollectionOfBlankSheet.Any(x => x.MinY.ToString() == item.ToString()),
                                    ColumnName = _columnName
                                };

                            CollectionOfFilterOptionsModels.Add(filterOptionsModel);
                        }
                    }
                    #endregion
                }
                else
                {
                    #region Blank ID
                    if (_columnName == "Blank ID")
                    {
                        foreach (var item in CollectionOfFilterOptionsModels.Where(x => x.ColumnName == _columnName))
                        {
                            item.IsSelected = CollectionOfBlankSheet.Any(x => x.BlankId == item.Title);
                        }
                    }
                    #endregion

                    #region Material
                    if (_columnName == "Material")
                    {
                        foreach (var item in CollectionOfFilterOptionsModels.Where(x => x.ColumnName == _columnName))
                        {
                            item.IsSelected = CollectionOfBlankSheet.Any(x => x.NewMaterial == item.Title);
                        }
                    }
                    #endregion

                    #region Thickness
                    if (_columnName == "Thickness")
                    {
                        foreach (var item in CollectionOfFilterOptionsModels.Where(x => x.ColumnName == _columnName))
                        {
                            item.IsSelected = CollectionOfBlankSheet.Any(x => x.NewThickness.ToString() == item.Title);
                        }
                    }
                    #endregion

                    #region X Size
                    if (_columnName == "X Size")
                    {
                        foreach (var item in CollectionOfFilterOptionsModels.Where(x => x.ColumnName == _columnName))
                        {
                            item.IsSelected = CollectionOfBlankSheet.Any(x => x.NewSizeX.ToString() == item.Title);
                        }
                    }
                    #endregion

                    #region Y Size
                    if (_columnName == "Y Size")
                    {
                        foreach (var item in CollectionOfFilterOptionsModels.Where(x => x.ColumnName == _columnName))
                        {
                            item.IsSelected = CollectionOfBlankSheet.Any(x => x.NewSizeY.ToString() == item.Title);
                        }
                    }
                    #endregion

                    #region Grip Width
                    if (_columnName == "Grip Width")
                    {
                        foreach (var item in CollectionOfFilterOptionsModels.Where(x => x.ColumnName == _columnName))
                        {
                            item.IsSelected = CollectionOfBlankSheet.Any(x => x.GripWidth.ToString() == item.Title);
                        }
                    }
                    #endregion

                    #region Trim (Up)
                    if (_columnName == "Trim (Up)")
                    {
                        foreach (var item in CollectionOfFilterOptionsModels.Where(x => x.ColumnName == _columnName))
                        {
                            item.IsSelected = CollectionOfBlankSheet.Any(x => x.TrimUp.ToString() == item.Title);
                        }
                    }
                    #endregion

                    #region Trim (Right)
                    if (_columnName == "Trim (Right)")
                    {
                        foreach (var item in CollectionOfFilterOptionsModels.Where(x => x.ColumnName == _columnName))
                        {
                            item.IsSelected = CollectionOfBlankSheet.Any(x => x.TrimRight.ToString() == item.Title);
                        }
                    }
                    #endregion

                    #region Trim (Left)
                    if (_columnName == "Trim (Left)")
                    {
                        foreach (var item in CollectionOfFilterOptionsModels.Where(x => x.ColumnName == _columnName))
                        {
                            item.IsSelected = CollectionOfBlankSheet.Any(x => x.TrimLeft.ToString() == item.Title);
                        }
                    }
                    #endregion

                    #region Stock Quantity
                    if (_columnName == "Stock Quantity")
                    {
                        foreach (var item in CollectionOfFilterOptionsModels.Where(x => x.ColumnName == _columnName))
                        {
                            item.IsSelected = CollectionOfBlankSheet.Any(x => x.StockQuantity.ToString() == item.Title);
                        }
                    }
                    #endregion

                    #region X Max
                    if (_columnName == "X Max")
                    {
                        foreach (var item in CollectionOfFilterOptionsModels.Where(x => x.ColumnName == _columnName))
                        {
                            item.IsSelected = CollectionOfBlankSheet.Any(x => x.MaxX.ToString() == item.Title);
                        }
                    }
                    #endregion

                    #region X Min
                    if (_columnName == "X Min")
                    {
                        foreach (var item in CollectionOfFilterOptionsModels.Where(x => x.ColumnName == _columnName))
                        {
                            item.IsSelected = CollectionOfBlankSheet.Any(x => x.MinX.ToString() == item.Title);
                        }
                    }
                    #endregion

                    #region Y Max
                    if (_columnName == "Y Max")
                    {
                        foreach (var item in CollectionOfFilterOptionsModels.Where(x => x.ColumnName == _columnName))
                        {
                            item.IsSelected = CollectionOfBlankSheet.Any(x => x.MaxY.ToString() == item.Title);
                        }
                    }
                    #endregion

                    #region Y Min
                    if (_columnName == "Y Min")
                    {
                        foreach (var item in CollectionOfFilterOptionsModels.Where(x => x.ColumnName == _columnName))
                        {
                            item.IsSelected = CollectionOfBlankSheet.Any(x => x.MinY.ToString() == item.Title);
                        }
                    }
                    #endregion
                }

                if (!string.IsNullOrEmpty(TextSearch))
                {
                    TextSearch = string.Empty;
                }

                _filterOptions = new FilterOptions { DataContext = this };
                _filterOptions.ShowDialog();
            }
        }
        #endregion

        #region Select UnSelect All Command
        private DelegateCommand _selectUnSelectAllCommand;
        public ICommand SelectUnSelectAllCommand => _selectUnSelectAllCommand ?? (_selectUnSelectAllCommand =
                                                        new DelegateCommand(OnSelectUnSelectAllCommand));

        private void OnSelectUnSelectAllCommand(object pName)
        {
            if (pName == null)
                return;

            foreach (var item in CollectionOfFilterOptionsModels.Where(x => x.ColumnName == _columnName))
            {
                item.IsSelected = (bool)pName;
            }
        }
        #endregion

        #region Filter Option Apply Command
        private DelegateCommand _filterOptionApplyCommand;
        public ICommand FilterOptionApplyCommand => _filterOptionApplyCommand ?? (_filterOptionApplyCommand =
                                                      new DelegateCommand(OnFilterOptionApplyCommand, CanFilterOptionApply));

        private bool CanFilterOptionApply(object pName)
        {

            if (TestCollection.Count(x => x.IsSelected) ==
                TestCollection.Count)
            {
                IsSelectAll = true;
            }
            else if (TestCollection.Count(x => x.IsSelected == false) ==
                     TestCollection.Count)
            {
                IsSelectAll = false;
            }
            else
            {
                IsSelectAll = null;
            }

            return TestCollection.Count(x => x.IsSelected) > 0;
        }

        private void OnFilterOptionApplyCommand(object pName)
        {
            //BlankSheetCollection.Filter = CustomerFilter;

            if (!ListOfFilterColumns.Contains(_columnName))
            {
                ListOfFilterColumns.Add(_columnName);
                OnPropertyChanged("ListOfFilterColumns");
            }

            //if (CollectionOfFilterOptionsModelsBackup.Count > 0)
            //{
            //    CollectionOfFilterOptionsModels =
            //        new ObservableCollection<FilterOptionsModel>(CollectionOfFilterOptionsModelsBackup);
            //    CollectionOfFilterOptionsModelsBackup.Clear();
            //}


            if (CollectionOfFilterOptionsModelsBackup.Count > 0)
            {
                foreach (var item in CollectionOfFilterOptionsModelsBackup)
                {
                    if (item.ColumnName == _columnName)
                    {
                        item.IsSelected = CollectionOfFilterOptionsModels
                            .Where(x => x.IsSelected)
                            .Contains(item);
                    }
                }

                CollectionOfFilterOptionsModels =
                        new ObservableCollection<FilterOptionsModel>(CollectionOfFilterOptionsModelsBackup);
                CollectionOfFilterOptionsModelsBackup.Clear();
            }

            //CancelFilterCommand.Execute(null);

            CollectionOfBlankSheet = CollectionOfBlankSheetBackup
                .Where(x => (ListOfFilterColumns.Contains("Blank ID") != true || CollectionOfFilterOptionsModels
                                 .Where(y => y.IsSelected && y.ColumnName == "Blank ID")
                                 .Any(z => z.Title == x.BlankId))
                    && (ListOfFilterColumns.Contains("Material") != true || CollectionOfFilterOptionsModels
                            .Where(y => y.IsSelected && y.ColumnName == "Material")
                            .Any(z => z.Title == x.NewMaterial))
                    && (ListOfFilterColumns.Contains("Thickness") != true || CollectionOfFilterOptionsModels
                            .Where(y => y.IsSelected && y.ColumnName == "Thickness")
                            .Any(z => z.Title == x.NewThickness.ToString()))
                    && (ListOfFilterColumns.Contains("X Size") != true || CollectionOfFilterOptionsModels
                            .Where(y => y.IsSelected && y.ColumnName == "X Size")
                            .Any(z => z.Title == x.NewSizeX.ToString()))
                    && (ListOfFilterColumns.Contains("Y Size") != true || CollectionOfFilterOptionsModels
                            .Where(y => y.IsSelected && y.ColumnName == "Y Size")
                            .Any(z => z.Title == x.NewSizeY.ToString()))
                    && (ListOfFilterColumns.Contains("Grip Width") != true || CollectionOfFilterOptionsModels
                            .Where(y => y.IsSelected && y.ColumnName == "Grip Width")
                            .Any(z => z.Title == x.GripWidth.ToString()))
                    && (ListOfFilterColumns.Contains("Trim (Up)") != true || CollectionOfFilterOptionsModels
                            .Where(y => y.IsSelected && y.ColumnName == "Trim (Up)")
                            .Any(z => z.Title == x.TrimUp.ToString()))
                    && (ListOfFilterColumns.Contains("Trim (Right)") != true || CollectionOfFilterOptionsModels
                            .Where(y => y.IsSelected && y.ColumnName == "Trim (Right)")
                            .Any(z => z.Title == x.TrimRight.ToString()))
                    && (ListOfFilterColumns.Contains("Trim (Left)") != true || CollectionOfFilterOptionsModels
                            .Where(y => y.IsSelected && y.ColumnName == "Trim (Left)")
                            .Any(z => z.Title == x.TrimLeft.ToString()))
                    && (ListOfFilterColumns.Contains("Stock Quantity") != true || CollectionOfFilterOptionsModels
                            .Where(y => y.IsSelected && y.ColumnName == "Stock Quantity")
                            .Any(z => z.Title == x.StockQuantity.ToString()))
                    && (ListOfFilterColumns.Contains("X Max") != true || CollectionOfFilterOptionsModels
                            .Where(y => y.IsSelected && y.ColumnName == "X Max")
                            .Any(z => z.Title == x.MaxX.ToString()))
                    && (ListOfFilterColumns.Contains("X Min") != true || CollectionOfFilterOptionsModels
                            .Where(y => y.IsSelected && y.ColumnName == "X Min")
                            .Any(z => z.Title == x.MinX.ToString()))
                    && (ListOfFilterColumns.Contains("Y Max") != true || CollectionOfFilterOptionsModels
                            .Where(y => y.IsSelected && y.ColumnName == "Y Max")
                            .Any(z => z.Title == x.MaxY.ToString()))
                    && (ListOfFilterColumns.Contains("Y Min") != true || CollectionOfFilterOptionsModels
                            .Where(y => y.IsSelected && y.ColumnName == "Y Min")
                            .Any(z => z.Title == x.MinY.ToString()))
                        )
                .ToObservableCollection();

            _filterOptions?.Close();
        }
        #endregion

        #region Clear Filter Command
        private DelegateCommand _clearFilterCommand;
        public ICommand ClearFilterCommand => _clearFilterCommand ?? (_clearFilterCommand =
                                                      new DelegateCommand(OnClearFilterCommandCommand));

        private void OnClearFilterCommandCommand(object pName)
        {
            var aaa = CollectionOfFilterOptionsModels.Where(x => x.ColumnName == _columnName).ToObservableCollection();
            foreach (var item in aaa)
            {
                item.IsSelected = true;
            }

            FilterOptionApplyCommand.Execute(null);

            ListOfFilterColumns.Remove(_columnName);

            if (ListOfFilterColumns.Count == 0)
            {
                ClearFilterFromAllColumnsCommand.Execute(null);
            }

            OnPropertyChanged("ListOfFilterColumns");

            _filterOptions?.Close();
        }
        #endregion

        #region Cancel Filter Command
        private DelegateCommand _cancelFilterCommand;
        public ICommand CancelFilterCommand => _cancelFilterCommand ?? (_cancelFilterCommand =
                                                  new DelegateCommand(OnCancelFilterCommandCommand));

        private void OnCancelFilterCommandCommand(object pName)
        {
            if (CollectionOfFilterOptionsModelsBackup.Count <= 0) return;

            CollectionOfFilterOptionsModels =
                new ObservableCollection<FilterOptionsModel>(CollectionOfFilterOptionsModelsBackup);
            CollectionOfFilterOptionsModelsBackup.Clear();
        }
        #endregion

        #region Clear Filter From All Columns Command
        private DelegateCommand _clearFilterFromAllColumnsCommand;
        public ICommand ClearFilterFromAllColumnsCommand => _clearFilterFromAllColumnsCommand ?? (_clearFilterFromAllColumnsCommand =
                                                  new DelegateCommand(OnClearFilterFromAllColumnsCommand, CanClearFilterFromAllColumns));

        private bool CanClearFilterFromAllColumns(object pName)
        {
            return ListOfFilterColumns.Count > 0;
        }

        private void OnClearFilterFromAllColumnsCommand(object pName)
        {
            CollectionOfFilterOptionsModels.Clear();
            CollectionOfFilterOptionsModelsBackup.Clear();
            CollectionOfBlankSheet = new ObservableCollection<BlankSheetModel>(CollectionOfBlankSheetBackup);
            CollectionOfBlankSheetBackup.Clear();

            ListOfFilterColumns.Clear();
            OnPropertyChanged("ListOfFilterColumns");

            _filterOptions?.Close();
        }
        #endregion

        #endregion
    }
}
