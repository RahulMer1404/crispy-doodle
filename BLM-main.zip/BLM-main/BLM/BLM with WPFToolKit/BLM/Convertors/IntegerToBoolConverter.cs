﻿using System;
using System.Windows.Data;

namespace BLM.Convertors
{
    public class IntegerToBoolConverter : IValueConverter
    {
        #region IValueConverter Members
        /// <summary>
        /// this is for convert integer value to bool
        /// </summary>
        /// <param name="value"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            try
            {
                if (parameter == null)
                {
                    if (value != null && int.Parse(value.ToString()) > 0)
                        return true;
                }

                if (parameter != null && parameter.ToString() == "single")
                {
                    if (value != null && int.Parse(value.ToString()) > 0)
                        return true;
                }

                if (parameter != null && parameter.ToString() == "multiple")
                {
                    if (value != null && int.Parse(value.ToString()) > 1)
                        return true;
                }

                return false;
            }
            catch
            {
                return false;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}