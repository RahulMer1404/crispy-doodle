﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Data;

namespace BLM.Convertors
{
    public class ColumnNameToFilterFunnelVisibilityConverter : IValueConverter
    {
        #region IValueConverter Members
        /// <summary>
        /// this is for convert Column Name To Filter Funnel Visibility
        /// </summary>
        /// <param name="value"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            try
            {
                //if (parameter != null && value != null)
                //{
                //    if (parameter.ToString() == value.ToString())
                //        return Visibility.Visible;
                //}

                List<string> list = value as List<string>;
                if (parameter != null && (list != null && list.Contains(parameter.ToString())))
                {
                    return Visibility.Visible;
                }

                return Visibility.Collapsed;
            }
            catch
            {
                return false;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}
