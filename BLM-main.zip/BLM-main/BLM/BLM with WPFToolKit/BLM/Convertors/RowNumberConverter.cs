﻿using System;
using System.Windows.Data;
using Microsoft.Windows.Controls;

namespace BLM.Convertors
{
    public class RowNumberConverter : IMultiValueConverter
    {
        #region IMultiValueConverter Members
        /// <summary>
        /// this is for convert items to row number
        /// </summary>
        /// <param name="values"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {

            //get the grid and the item
            var item = values[0];
            DataGrid grid = values[1] as DataGrid;

            if (grid != null)
            {
                int index = grid.Items.IndexOf(item);

                return (index + 1).ToString();
            }

            return 0;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}
