﻿using System;
using System.Windows.Data;
using System.Windows.Controls;

namespace BLM.Convertors
{
    public class RowIndexConverter : IValueConverter
    {
        #region IValueConverter Members
        /// <summary>
        /// this is for convert items to row number
        /// </summary>
        /// <param name="value"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            ListViewItem item = (ListViewItem)value;
            ListView listView = ItemsControl.ItemsControlFromItemContainer(item) as ListView;
            if (listView != null)
            {
                int index = listView.ItemContainerGenerator.IndexFromContainer(item);
                return (index + 1).ToString();
            }

            return "0";
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}
