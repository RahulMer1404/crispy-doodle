﻿using System;
using System.Windows.Data;

namespace BLM.Convertors
{
    public class NullableValueConverter : IValueConverter
    {
        #region IValueConverter Members
        /// <summary>
        /// this is for convert blank value to null
        /// </summary>
        /// <param name="value"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return value;
        }

        /// <summary>
        /// this is for convert blank value to null
        /// </summary>
        /// <param name="value"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value == null)
                return null;

            if (string.IsNullOrEmpty(value.ToString()))
                return null;

            return value;
        }
        #endregion
    }
}
