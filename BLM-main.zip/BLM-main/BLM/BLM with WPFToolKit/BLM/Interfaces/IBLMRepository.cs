﻿using BLM.Models;
using System.Collections.ObjectModel;

namespace BLM.Interfaces
{
    public interface IBlmRepository
    {
        ObservableCollection<BlankSheetModel> GetAllBlankSheet();
        ObservableCollection<MaterialModel> GetAllMaterial();
        ObservableCollection<ThicknessModel> GetAllThickness();
        ObservableCollection<SizeXModel> GetAllSizeX();
        ObservableCollection<SizeYModel> GetAllSizeY();
        string GetInputUnit();
        void SaveBlankSheet(ObservableCollection<BlankSheetModel> pcollectionOfBlankSheet);
    }
}
