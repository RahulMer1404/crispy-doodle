﻿namespace BLM.Models
{
    public class ThicknessModel : BaseModel
    {
        #region Ctor
        public ThicknessModel(float pThicknessLong, float pThicknessSmall)
        {
            ThicknessLong = pThicknessLong;
            ThicknessSmall = pThicknessSmall;
        }

        public ThicknessModel()
        {

        }
        #endregion

        #region Properties
        private float? _thicknessLong;
        public float? ThicknessLong
        {
            get { return _thicknessLong; }
            set { _thicknessLong = value; OnPropertyChanged("ThicknessLong"); }
        }

        private float? _thicknessSmall;
        public float? ThicknessSmall
        {
            get { return _thicknessSmall; }
            set { _thicknessSmall = value; OnPropertyChanged("ThicknessSmall"); }
        }
        #endregion
    }
}
