﻿namespace BLM.Models
{
    public class SizeYModel : BaseModel
    {
        #region Ctor
        public SizeYModel(string pSizeDetail, float pSizeY)
        {
            SizeDetail = pSizeDetail;
            SizeY = pSizeY;
        }

        public SizeYModel()
        {

        }
        #endregion

        #region Properties
        private string _sizeDetail;
        public string SizeDetail
        {
            get { return _sizeDetail; }
            set { _sizeDetail = value; OnPropertyChanged("SizeDetail"); }
        }

        private float? _sizeY;
        public float? SizeY
        {
            get { return _sizeY; }
            set { _sizeY = value; OnPropertyChanged("SizeY"); }
        }
        #endregion
    }
}
