﻿namespace BLM.Models
{
    public class SizeXModel : BaseModel
    {
        #region Ctor
        public SizeXModel(string pSizeDetail, float pSizeX)
        {
            SizeDetail = pSizeDetail;
            SizeX = pSizeX;
        }

        public SizeXModel()
        {

        }
        #endregion

        #region Properties
        private string _sizeDetail;
        public string SizeDetail
        {
            get { return _sizeDetail; }
            set { _sizeDetail = value; OnPropertyChanged("SizeDetail"); }
        }

        private float? _sizeX;
        public float? SizeX
        {
            get { return _sizeX; }
            set { _sizeX = value; OnPropertyChanged("SizeX"); }
        }
        #endregion
    }
}
