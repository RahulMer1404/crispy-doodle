﻿namespace BLM.Models
{
    public class MaterialModel : BaseModel
    {
        #region Ctor
        public MaterialModel(string pMaterialKey, string pMaterialName)
        {
            MaterialKey = pMaterialKey;
            MaterialName = pMaterialName;
        }

        public MaterialModel()
        {

        }
        #endregion

        #region Properties
        private string _materialKey;
        public string MaterialKey
        {
            get { return _materialKey; }
            set { _materialKey = value; OnPropertyChanged("MaterialKey"); }
        }

        private string _materialName;
        public string MaterialName
        {
            get { return _materialName; }
            set { _materialName = value; OnPropertyChanged("MaterialName"); }
        }
        #endregion
    }
}
