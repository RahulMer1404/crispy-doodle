﻿namespace BLM.Models
{
    public class SortOptionModel : BaseModel
    {
        private string _title;
        public string Title
        {
            get { return _title; }
            set { _title = value; OnPropertyChanged("Title"); }
        }

        private string _imageSource;
        public string ImageSource
        {
            get { return _imageSource; }
            set
            {
                _imageSource = value;
                OnPropertyChanged("ImageSource");
            }
        }

        private int _titleNumber;
        public int TitleNumber
        {
            get { return _titleNumber; }
            set { _titleNumber = value; OnPropertyChanged("TitleNumber"); }
        }

        private bool _isAscending;
        public bool IsAscending
        {
            get { return _isAscending; }
            set { _isAscending = value; OnPropertyChanged("IsAscending"); }
        }

        private string _propertyName;
        public string PropertyName
        {
            get { return _propertyName; }
            set { _propertyName = value; OnPropertyChanged("PropertyName"); }
        }
    }
}
