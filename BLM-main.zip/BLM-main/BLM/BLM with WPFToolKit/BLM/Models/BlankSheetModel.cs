﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;

namespace BLM.Models
{
    public class BlankSheetModel : BaseModel, IDataErrorInfo
    {
        #region Properties

        private void SetIsAddOrEdit(object pOldValue, object pNewValue, string ppropertyName = "")
        {
            if (pOldValue is float)
            {
                // ReSharper disable once CompareOfFloatsByEqualityOperator
                // ReSharper disable once ConditionIsAlwaysTrueOrFalse
                if ((float)pOldValue != 0 && pOldValue != null && (float)pOldValue != (float?)pNewValue)
                {
                    IsAddOrEdit = "*";
                    return;
                }
            }

            if (pOldValue is string)
            {
                if (pOldValue != pNewValue)
                {
                    IsAddOrEdit = "*";
                    return;
                }
            }

            if (pOldValue is int)
            {
                if ((int)pOldValue != 0 && (int)pOldValue != (int?)pNewValue)
                {
                    IsAddOrEdit = "*";
                    return;
                }
            }

            if (ppropertyName == "MaxX" || ppropertyName == "MinX" || ppropertyName == "MaxY" || ppropertyName == "MinY")
            {
                if (pNewValue != null && (float?) pOldValue != (float) pNewValue)
                {
                    IsAddOrEdit = "*";
                }
            }
        }

        private int _blankSheetId;
        public int BlankSheetId
        {
            get { return _blankSheetId; }
            set { _blankSheetId = value; OnPropertyChanged("BlankSheetId"); }
        }

        private string _isAddOrEdit;
        public string IsAddOrEdit
        {
            get { return _isAddOrEdit; }
            set { _isAddOrEdit = value; OnPropertyChanged("IsAddOrEdit"); }
        }

        private string _inputUnit;
        public string InputUnit
        {
            get { return _inputUnit; }
            set { _inputUnit = value; OnPropertyChanged("InputUnit"); }
        }

        private string _blankId;
        public string BlankId
        {
            get { return _blankId; }
            set
            {
                SetIsAddOrEdit(BlankId, value);

                _blankId = value;
                OnPropertyChanged("BlankId");
            }
        }

        //private string _material;
        //public string Material
        //{
        //    get { return _material; }
        //    set
        //    {
        //        SetIsAddOrEdit(Material, value);

        //        _material = value;
        //        OnPropertyChanged("Material");
        //    }
        //}

        //private float _thickness;
        //public float Thickness
        //{
        //    get { return _thickness; }
        //    set
        //    {
        //        _thickness = value;
        //        OnPropertyChanged("Thickness");
        //    }
        //}

        //private float _sizeX;
        //public float SizeX
        //{
        //    get { return _sizeX; }
        //    set
        //    {
        //        SetIsAddOrEdit(SizeX, value);

        //        _sizeX = value;
        //        OnPropertyChanged("SizeX");
        //    }
        //}

        //private float _sizeY;
        //public float SizeY
        //{
        //    get { return _sizeY; }
        //    set
        //    {
        //        SetIsAddOrEdit(SizeY, value);

        //        _sizeY = value;
        //        OnPropertyChanged("SizeY");
        //    }
        //}

        private float? _gripWidth = 0;
        public float? GripWidth
        {
            get { return _gripWidth; }
            set
            {
                SetIsAddOrEdit(GripWidth, value);

                _gripWidth = value;
                OnPropertyChanged("GripWidth");
            }
        }

        private float? _trimUp = 0;
        public float? TrimUp
        {
            get { return _trimUp; }
            set
            {
                SetIsAddOrEdit(TrimUp, value);

                _trimUp = value;
                OnPropertyChanged("TrimUp");
            }
        }

        private float? _trimRight = 0;
        public float? TrimRight
        {
            get { return _trimRight; }
            set
            {
                SetIsAddOrEdit(TrimRight, value);

                _trimRight = value;
                OnPropertyChanged("TrimRight");
            }
        }

        private float? _trimLeft = 0;
        public float? TrimLeft
        {
            get { return _trimLeft; }
            set
            {
                SetIsAddOrEdit(TrimLeft, value);

                _trimLeft = value;
                OnPropertyChanged("TrimLeft");
            }
        }

        private int? _stockQuantity = 0;
        public int? StockQuantity
        {
            get { return _stockQuantity; }
            set
            {
                SetIsAddOrEdit(StockQuantity, value);

                _stockQuantity = value;
                OnPropertyChanged("StockQuantity");
            }
        }

        private float? _maxX;
        public float? MaxX
        {
            get { return _maxX; }
            set
            {
                SetIsAddOrEdit(MaxX, value, "MaxX");

                _maxX = value;
                OnPropertyChanged("MaxX");
            }
        }

        private float? _minX;
        public float? MinX
        {
            get { return _minX; }
            set
            {
                SetIsAddOrEdit(MinX, value, "MinX");

                _minX = value;
                OnPropertyChanged("MinX");
            }
        }

        private float? _maxY;
        public float? MaxY
        {
            get { return _maxY; }
            set
            {
                SetIsAddOrEdit(MaxY, value, "MaxY");

                _maxY = value;
                OnPropertyChanged("MaxY");
            }
        }

        private float? _minY;
        public float? MinY
        {
            get { return _minY; }
            set
            {
                SetIsAddOrEdit(MinY, value, "MinY");

                _minY = value;
                OnPropertyChanged("MinY");
            }
        }

        private int _mAtCode;
        public int MatCode
        {
            get { return _mAtCode; }
            set
            {
                SetIsAddOrEdit(MatCode, value);

                _mAtCode = value;
                OnPropertyChanged("MATCode");
            }
        }

        private int _sortingCode;
        public int SortingCode
        {
            get { return _sortingCode; }
            set
            {
                SetIsAddOrEdit(SortingCode, value);

                _sortingCode = value;
                OnPropertyChanged("SortingCode");
            }
        }

        #region Material

        public static ObservableCollection<MaterialModel> CollectionOfMaterialStatic { get; set; }

        private MaterialModel _selectedMaterial;
        public MaterialModel SelectedMaterial
        {
            get { return _selectedMaterial; }
            set
            {
                _selectedMaterial = value;
                if (_selectedMaterial != null)
                    NewMaterial = _selectedMaterial.MaterialName;
                OnPropertyChanged("SelectedMaterial");
            }
        }

        private string _newMaterial;
        public string NewMaterial
        {
            get { return _newMaterial; }
            set
            {
                SetIsAddOrEdit(NewMaterial, value);

                _newMaterial = value;

                // ReSharper disable once CompareOfFloatsByEqualityOperator
                var existMaterial = CollectionOfMaterialStatic.FirstOrDefault(x => x.MaterialName == _newMaterial);
                if (existMaterial == null)
                {
                    SelectedMaterial = null;
                }

                OnPropertyChanged("NewMaterial");
            }
        }

        #endregion

        #region SizeX

        public static ObservableCollection<SizeXModel> CollectionOfSizeXStatic { get; set; }

        private SizeXModel _selectedSizeX;
        public SizeXModel SelectedSizeX
        {
            get { return _selectedSizeX; }
            set
            {
                _selectedSizeX = value;
                OnPropertyChanged("SelectedSizeX");
            }
        }

        private float? _newSizeX;
        public float? NewSizeX
        {
            get { return _newSizeX; }
            set
            {
                SetIsAddOrEdit(NewSizeX, value);

                _newSizeX = value;
                OnPropertyChanged("NewSizeX");
            }
        }
        #endregion

        #region SizeY

        public static ObservableCollection<SizeYModel> CollectionOfSizeYStatic { get; set; }

        private SizeYModel _selectedSizeY;
        public SizeYModel SelectedSizeY
        {
            get { return _selectedSizeY; }
            set
            {
                _selectedSizeY = value;
                OnPropertyChanged("SelectedSizeY");
            }
        }

        private float? _newSizeY;
        public float? NewSizeY
        {
            get { return _newSizeY; }
            set
            {
                SetIsAddOrEdit(NewSizeY, value);

                _newSizeY = value;
                OnPropertyChanged("NewSizeY");
            }
        }
        #endregion

        #region Thickness

        public static ObservableCollection<ThicknessModel> CollectionOfThicknessStatic { get; set; }

        private ThicknessModel _selectedThickness;
        public ThicknessModel SelectedThickness
        {
            get { return _selectedThickness; }
            set
            {
                _selectedThickness = value;
                if(_selectedThickness != null)
                    NewThickness = _selectedThickness.ThicknessSmall;
                OnPropertyChanged("SelectedThickness");
            }
        }

        private float? _newThickness;
        public float? NewThickness
        {
            get { return _newThickness; }
            set
            {
                SetIsAddOrEdit(NewThickness, value);

                _newThickness = value;

                // ReSharper disable once CompareOfFloatsByEqualityOperator
                var existThickness = CollectionOfThicknessStatic.FirstOrDefault(x => x.ThicknessSmall == _newThickness);
                if (existThickness == null)
                {
                    SelectedThickness = null;
                }

                OnPropertyChanged("NewThickness");
            }
        }
        #endregion

        public static double MaxValueSupport { get; set; }

        public static double MaxValueSupportSmall { get; set; }

        public bool IsGroupEdit { get; set; }

        private string _columnName;
        public string ColumnName
        {
            get { return _columnName; }
            set { _columnName = value; OnPropertyChanged("ColumnName"); }
        }

        public string Error => null;

        readonly Dictionary<string, string> _errorCollection = new Dictionary<string, string>();
        public string this[string columnName]
        {
            get
            {
                if (columnName == "BlankId")
                {
                    int number;
                    bool result = Int32.TryParse(BlankId, out number);

                    if (string.IsNullOrEmpty(BlankId) || (result && number == 0))
                    {
                        if (_errorCollection.Count(x => x.Key == columnName) == 0)
                        {
                            _errorCollection.Add(columnName, columnName);
                            ShowMessage("Blank Id should not be allowed with empty or '0' value!");
                        }
                        return "Blank Id should not be allowed with empty or '0' value!";
                    }
                }

                if (columnName == "NewMaterial")
                {
                    int number;
                    bool result = Int32.TryParse(string.IsNullOrEmpty(NewMaterial) ? SelectedMaterial?.MaterialName : NewMaterial, out number);

                    if (string.IsNullOrEmpty(string.IsNullOrEmpty(NewMaterial) ? SelectedMaterial?.MaterialName : NewMaterial) || (result && number == 0))
                    {
                        if (_errorCollection.Count(x => x.Key == columnName) == 0)
                        {
                            _errorCollection.Add(columnName, columnName);
                            ShowMessage("Material should not be allowed with empty or '0' value!");
                        }
                        return "Material should not be allowed with empty or '0' value!";
                    }
                }

                if (columnName == "NewThickness")
                {
                    var testThickness = NewThickness ?? SelectedThickness?.ThicknessSmall;
                    if (testThickness == null || testThickness <= 0)
                    {
                        if (_errorCollection.Count(x => x.Key == columnName) == 0)
                        {
                            _errorCollection.Add(columnName, columnName);
                            ShowMessage("Thickness should not be allowed with empty or '0' value!");
                        }
                        return "Thickness should not be allowed with empty or '0' value!";
                    }
                }

                if (columnName == "NewSizeX")
                {
                    var testSizeX = NewSizeX ?? SelectedSizeX?.SizeX;
                    if (testSizeX == null || testSizeX <= 0)
                    {
                        if (_errorCollection.Count(x => x.Key == columnName) == 0)
                        {
                            _errorCollection.Add(columnName, columnName);
                            ShowMessage("X Size should not be allowed with empty or '0' value!");
                        }
                        return "X Size should not be allowed with empty or '0' value!";
                    }
                }

                if (columnName == "NewSizeY")
                {
                    var testSizeY = NewSizeY ?? SelectedSizeY?.SizeY;
                    if (testSizeY == null || testSizeY <= 0)
                    {
                        if (_errorCollection.Count(x => x.Key == columnName) == 0)
                        {
                            _errorCollection.Add(columnName, columnName);
                            ShowMessage("Y Size should not be allowed with empty or '0' value!");
                        }
                        return "Y Size should not be allowed with empty or '0' value!";
                    }
                }

                if (columnName == "GripWidth")
                {
                    if (GripWidth == null || GripWidth < 0)
                    {
                        if (_errorCollection.Count(x => x.Key == columnName) == 0)
                        {
                            _errorCollection.Add(columnName, columnName);
                            ShowMessage("Grip Width should not be allowed with empty value!");
                        }
                        return "Grip Width should not be allowed with empty value!";
                    }
                }

                if (columnName == "TrimUp")
                {
                    if (TrimUp == null || TrimUp < 0)
                    {
                        if (_errorCollection.Count(x => x.Key == columnName) == 0)
                        {
                            _errorCollection.Add(columnName, columnName);
                            ShowMessage("Trim Up should not be allowed with empty value!");
                        }
                        return "Trim Up should not be allowed with empty value!";
                    }
                }

                if (columnName == "TrimRight")
                {
                    if (TrimRight == null || TrimRight < 0)
                    {
                        if (_errorCollection.Count(x => x.Key == columnName) == 0)
                        {
                            _errorCollection.Add(columnName, columnName);
                            ShowMessage("Trim Right should not be allowed with empty value!");
                        }
                        return "Trim Right should not be allowed with empty value!";
                    }
                }

                if (columnName == "TrimLeft")
                {
                    if (TrimLeft == null || TrimLeft < 0)
                    {
                        if (_errorCollection.Count(x => x.Key == columnName) == 0)
                        {
                            _errorCollection.Add(columnName, columnName);
                            ShowMessage("Trim Left should not be allowed with empty value!");
                        }
                        return "Trim Left should not be allowed with empty value!";
                    }
                }

                if (columnName == "StockQuantity")
                {
                    if (StockQuantity == null || StockQuantity < 0)
                    {
                        if (_errorCollection.Count(x => x.Key == columnName) == 0)
                        {
                            _errorCollection.Add(columnName, columnName);
                            ShowMessage("Stock Quantity should not be allowed with empty value!");
                        }
                        return "Stock Quantity should not be allowed with empty value!";
                    }
                }


                if (columnName == "MaxX")
                {
                    if (IsGroupEdit) return null;

                    if (MaxX == null && MinX != null)
                    {
                        if (_errorCollection.Count(x => x.Key == columnName) == 0)
                        {
                            _errorCollection.Add(columnName, columnName);
                            ShowMessage("Please enter X Max value!");
                        }
                        return "Please enter X Max value!";
                    }

                    if (MaxX != null && MinX != null && MinX > MaxX)
                    {
                        if (_errorCollection.Count(x => x.Key == columnName) == 0)
                        {
                            _errorCollection.Add(columnName, columnName);
                            ShowMessage("Please enter X Max value greater than or equal to X Min value!");
                        }
                        return "Please enter X Max value greater than or equal to X Min value!";
                    }

                    if (MaxX != null && MaxX > NewSizeX)
                    {
                        if (_errorCollection.Count(x => x.Key == columnName) == 0)
                        {
                            _errorCollection.Add(columnName, columnName);
                            ShowMessage("Please enter X Max value less than or equal to X Size value!");
                        }
                        return "Please enter X Max value less than or equal to X Size value!";
                    }
                }

                if (columnName == "MinX")
                {
                    if (IsGroupEdit) return null;

                    if (MaxX != null && MinX == null)
                    {
                        if (_errorCollection.Count(x => x.Key == columnName) == 0)
                        {
                            _errorCollection.Add(columnName, columnName);
                            ShowMessage("Please enter X Min value!");
                        }
                        return "Please enter X Min value!";
                    }

                    if (MaxX != null && MinX != null && MinX > MaxX)
                    {
                        if (_errorCollection.Count(x => x.Key == columnName) == 0)
                        {
                            _errorCollection.Add(columnName, columnName);
                            ShowMessage("Please enter X Min value less than or equal to X Max value!");
                        }
                        return "Please enter X Min value less than or equal to X Max value!";
                    }
                }

                if (columnName == "MaxY")
                {
                    if (IsGroupEdit) return null;

                    if (MaxY == null && MinY != null)
                    {
                        if (_errorCollection.Count(x => x.Key == columnName) == 0)
                        {
                            _errorCollection.Add(columnName, columnName);
                            ShowMessage("Please enter Y Max value!");
                        }
                        return "Please enter Y Max value!";
                    }

                    if (MaxY != null && MinY != null && MinY > MaxY)
                    {
                        if (_errorCollection.Count(x => x.Key == columnName) == 0)
                        {
                            _errorCollection.Add(columnName, columnName);
                            ShowMessage("Please enter Y Max value greater than or equal to Y Min value!");
                        }
                        return "Please enter Y Max value greater than or equal to Y Min value!";
                    }

                    if (MaxY != null && MaxY > NewSizeY)
                    {
                        if (_errorCollection.Count(x => x.Key == columnName) == 0)
                        {
                            _errorCollection.Add(columnName, columnName);
                            ShowMessage("Please enter Y Max value less than or equal to Y Size value!");
                        }
                        return "Please enter Y Max value less than or equal to Y Size value!";
                    }
                }

                if (columnName == "MinY")
                {
                    if (IsGroupEdit) return null;

                    if (MaxY != null && MinY == null)
                    {
                        if (_errorCollection.Count(x => x.Key == columnName) == 0)
                        {
                            _errorCollection.Add(columnName, columnName);
                            ShowMessage("Please enter Y Min value!");
                        }
                        return "Please enter Y Min value!";
                    }

                    if (MaxY != null && MinY != null && MinY > MaxY)
                    {
                        if (_errorCollection.Count(x => x.Key == columnName) == 0)
                        {
                            _errorCollection.Add(columnName, columnName);
                            ShowMessage("Please enter Y Min value less than or equal to Y Max value!");
                        }
                        return "Please enter Y Min value less than or equal to Y Max value!";
                    }
                }

                return null;
            }
        }

        public void ShowMessage(string error)
        {
            System.Windows.Threading.Dispatcher.CurrentDispatcher.BeginInvoke(new Action(() =>
            {
                MessageBox.Show(error, "Error", MessageBoxButton.OK, MessageBoxImage.Error);

                _errorCollection.Clear();
            }));
        }

        #endregion
    }
}
