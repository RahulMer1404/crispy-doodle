﻿using System.Windows.Input;
using BLM.ViewModels;

namespace BLM.Views
{
    /// <summary>
    /// Interaction logic for FilterOptions.xaml
    /// </summary>
    public partial class FilterOptions
    {
        #region Variables
        #endregion

        #region Ctor
        public FilterOptions()
        {
            InitializeComponent();
            Mouse.OverrideCursor = Cursors.Arrow;

            Closed += FilterOptions_Closed;
        }
        #endregion

        #region Events
        private void FilterOptions_Closed(object sender, System.EventArgs e)
        {
            MainViewModel mainViewModel = DataContext as MainViewModel;
            mainViewModel?.CancelFilterCommand.Execute(null);
        }
        #endregion
    }
}
