﻿using System.Windows.Input;

namespace BLM.Views
{
    /// <summary>
    /// Interaction logic for BlankSheetRegistrationWindow.xaml
    /// </summary>
    public partial class BlankSheetRegistrationWindow
    {
        #region Variables
        public bool IsNewBlankSheet;
        #endregion

        #region Ctor
        public BlankSheetRegistrationWindow(bool pIsNewBlankSheet)
        {
            InitializeComponent();
            Mouse.OverrideCursor = Cursors.Arrow;

            IsNewBlankSheet = pIsNewBlankSheet;
            TbBlankId.IsEnabled = pIsNewBlankSheet;

            //Application.Current.Resources["inputFormat"] = StaticHelperClass.InputFormat;
        }
        #endregion
    }
}
