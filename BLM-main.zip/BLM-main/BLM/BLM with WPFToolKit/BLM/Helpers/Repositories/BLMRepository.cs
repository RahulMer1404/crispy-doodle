﻿using System;
using System.Collections.ObjectModel;
using BLM.Interfaces;
using BLM.Models;
using System.IO;
using System.Text.RegularExpressions;
using System.Linq;
using System.Collections.Generic;
using System.Globalization;
using BLM.Helpers.Common;

namespace BLM.Helpers.Repositories
{
    public class BlmRepository : IBlmRepository
    {
        #region Variables
        string folderPath = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase) + @"\DataFiles\";
        private readonly ErrorLogHelper _errorLogHelper = new ErrorLogHelper();
        #endregion

        #region Properites
        #endregion

        #region Ctor
        #endregion

        #region Methods
        public ObservableCollection<BlankSheetModel> GetAllBlankSheet()
        {
            ObservableCollection<BlankSheetModel> collectionOfBlankSheet = new ObservableCollection<BlankSheetModel>();
            try
            {
                StreamReader objInput = new StreamReader(new Uri(folderPath + "Blmaster.dat").LocalPath, System.Text.Encoding.Default);
                string contents = objInput.ReadToEnd().Trim();
                string[] splitRows = Regex.Split(contents, "\r\n", RegexOptions.None);


                BlankSheetModel.CollectionOfMaterialStatic = GetAllMaterial();
                BlankSheetModel.CollectionOfThicknessStatic = GetAllThickness();
                BlankSheetModel.CollectionOfSizeXStatic = GetAllSizeX();
                BlankSheetModel.CollectionOfSizeYStatic = GetAllSizeY();

                int counter = 1;
                foreach (string row in splitRows)
                {
                    string[] splitColumns = Regex.Split(row, " ", RegexOptions.None);
                    List<string> listOfColumns = splitColumns.Where(x => !string.IsNullOrEmpty(x)).ToList();

                    BlankSheetModel blankSheetModel = new BlankSheetModel();

                    blankSheetModel.BlankSheetId = counter;
                    blankSheetModel.MatCode = int.Parse(listOfColumns[0], CultureInfo.InvariantCulture.NumberFormat);
                    blankSheetModel.BlankId = listOfColumns[1];

                    // ReSharper disable once ReplaceWithSingleCallToFirstOrDefault
                    // ReSharper disable once CompareOfFloatsByEqualityOperator
                    if (BlankSheetModel.CollectionOfSizeXStatic.Where(x => x.SizeX == float.Parse((listOfColumns[2]), CultureInfo.InvariantCulture.NumberFormat)).FirstOrDefault() == null)
                    {
                        blankSheetModel.NewSizeX = float.Parse((listOfColumns[2]), CultureInfo.InvariantCulture.NumberFormat);
                    }
                    else
                    {
                        // ReSharper disable once ReplaceWithSingleCallToFirstOrDefault
                        // ReSharper disable once CompareOfFloatsByEqualityOperator
                        blankSheetModel.SelectedSizeX = BlankSheetModel.CollectionOfSizeXStatic.Where(x => x.SizeX == float.Parse((listOfColumns[2]), CultureInfo.InvariantCulture.NumberFormat)).FirstOrDefault();
                    }

                    // ReSharper disable once ReplaceWithSingleCallToFirstOrDefault
                    // ReSharper disable once CompareOfFloatsByEqualityOperator
                    if (BlankSheetModel.CollectionOfSizeYStatic.Where(x => x.SizeY == float.Parse((listOfColumns[3]), CultureInfo.InvariantCulture.NumberFormat)).FirstOrDefault() == null)
                    {
                        blankSheetModel.NewSizeY = float.Parse((listOfColumns[3]), CultureInfo.InvariantCulture.NumberFormat);
                    }
                    else
                    {
                        // ReSharper disable once ReplaceWithSingleCallToFirstOrDefault
                        // ReSharper disable once CompareOfFloatsByEqualityOperator
                        blankSheetModel.SelectedSizeY = BlankSheetModel.CollectionOfSizeYStatic.Where(x => x.SizeY == float.Parse((listOfColumns[3]), CultureInfo.InvariantCulture.NumberFormat)).FirstOrDefault();
                    }

                    // ReSharper disable once ReplaceWithSingleCallToFirstOrDefault
                    // ReSharper disable once CompareOfFloatsByEqualityOperator
                    if (BlankSheetModel.CollectionOfMaterialStatic.Where(x => x.MaterialName == listOfColumns[4]).FirstOrDefault() == null)
                    {
                        blankSheetModel.NewMaterial = listOfColumns[4];
                    }
                    else
                    {
                        // ReSharper disable once ReplaceWithSingleCallToFirstOrDefault
                        // ReSharper disable once CompareOfFloatsByEqualityOperator
                        blankSheetModel.SelectedMaterial = BlankSheetModel.CollectionOfMaterialStatic.Where(x => x.MaterialName == listOfColumns[4]).FirstOrDefault();
                    }

                    // ReSharper disable once ReplaceWithSingleCallToFirstOrDefault
                    // ReSharper disable once CompareOfFloatsByEqualityOperator
                    if (BlankSheetModel.CollectionOfThicknessStatic.Where(x => x.ThicknessSmall == float.Parse((listOfColumns[5]), CultureInfo.InvariantCulture.NumberFormat)).FirstOrDefault() == null)
                    {
                        blankSheetModel.NewThickness = float.Parse((listOfColumns[5]), CultureInfo.InvariantCulture.NumberFormat);
                    }
                    else
                    {
                        // ReSharper disable once ReplaceWithSingleCallToFirstOrDefault
                        // ReSharper disable once CompareOfFloatsByEqualityOperator
                        blankSheetModel.SelectedThickness = BlankSheetModel.CollectionOfThicknessStatic.Where(x => x.ThicknessSmall == float.Parse((listOfColumns[5]), CultureInfo.InvariantCulture.NumberFormat)).FirstOrDefault();
                    }

                    blankSheetModel.GripWidth = float.Parse((listOfColumns[6]), CultureInfo.InvariantCulture.NumberFormat);
                    blankSheetModel.TrimUp = float.Parse((listOfColumns[7]), CultureInfo.InvariantCulture.NumberFormat);
                    blankSheetModel.TrimRight = float.Parse((listOfColumns[8]), CultureInfo.InvariantCulture.NumberFormat);
                    blankSheetModel.TrimLeft = float.Parse((listOfColumns[9]), CultureInfo.InvariantCulture.NumberFormat);
                    blankSheetModel.StockQuantity = int.Parse((listOfColumns[10]), CultureInfo.InvariantCulture.NumberFormat);
                    blankSheetModel.SortingCode = int.Parse((listOfColumns[11]), CultureInfo.InvariantCulture.NumberFormat);

                    collectionOfBlankSheet.Add(blankSheetModel);

                    counter++;
                }
            }
            catch (Exception ex)
            {
                _errorLogHelper.LogErrorAsync("BLMRepository", "GetAllBlankSheet", ex);
            }

            return collectionOfBlankSheet;
        }

        public ObservableCollection<MaterialModel> GetAllMaterial()
        {
            ObservableCollection<MaterialModel> collectionOfMaterial = new ObservableCollection<MaterialModel>();

            try
            {
                StreamReader objInput = new StreamReader(new Uri(folderPath + "BLMATE.DAT").LocalPath, System.Text.Encoding.Default);
                string contents = objInput.ReadToEnd().Trim();
                string[] splitRows = Regex.Split(contents, "\r\n", RegexOptions.None);
                foreach (string row in splitRows)
                {
                    string[] splitColumns = Regex.Split(row, " ", RegexOptions.None);
                    List<string> listOfColumns = splitColumns.Where(x => !string.IsNullOrEmpty(x)).ToList();

                    MaterialModel materialModel = new MaterialModel();
                    materialModel.MaterialKey = listOfColumns[0];
                    materialModel.MaterialName = listOfColumns[1];

                    collectionOfMaterial.Add(materialModel);
                }
            }
            catch (Exception ex)
            {
                _errorLogHelper.LogErrorAsync("BLMRepository", "GetAllMaterial", ex);
            }

            return collectionOfMaterial.OrderBy(x => x.MaterialName).ToObservableCollection();
        }

        public ObservableCollection<SizeXModel> GetAllSizeX()
        {
            ObservableCollection<SizeXModel> collectionOfSize = new ObservableCollection<SizeXModel>();

            try
            {
                StreamReader objInput = new StreamReader(new Uri(folderPath + "BLSIZE.DAT").LocalPath, System.Text.Encoding.Default);
                string contents = objInput.ReadToEnd().Trim();
                string[] splitRows = Regex.Split(contents, "\r\n", RegexOptions.None);
                foreach (string row in splitRows)
                {
                    string[] splitColumns = Regex.Split(row, "   ", RegexOptions.None);
                    List<string> listOfColumns = splitColumns.Where(x => !string.IsNullOrEmpty(x)).ToList();

                    SizeXModel sizeModel = new SizeXModel();
                    sizeModel.SizeDetail = listOfColumns[0];
                    sizeModel.SizeX = float.Parse((listOfColumns[1]), CultureInfo.InvariantCulture.NumberFormat);

                    collectionOfSize.Add(sizeModel);
                }
            }
            catch (Exception ex)
            {
                _errorLogHelper.LogErrorAsync("BLMRepository", "GetAllSizeX", ex);
            }

            return collectionOfSize.OrderBy(x => x.SizeX).ToObservableCollection();
        }

        public ObservableCollection<SizeYModel> GetAllSizeY()
        {
            ObservableCollection<SizeYModel> collectionOfSize = new ObservableCollection<SizeYModel>();

            try
            {
                StreamReader objInput = new StreamReader(new Uri(folderPath + "BLSIZE.DAT").LocalPath, System.Text.Encoding.Default);
                string contents = objInput.ReadToEnd().Trim();
                string[] splitRows = Regex.Split(contents, "\r\n", RegexOptions.None);
                foreach (string row in splitRows)
                {
                    string[] splitColumns = Regex.Split(row, "   ", RegexOptions.None);
                    List<string> listOfColumns = splitColumns.Where(x => !string.IsNullOrEmpty(x)).ToList();

                    SizeYModel sizeModel = new SizeYModel();
                    sizeModel.SizeDetail = listOfColumns[0];
                    sizeModel.SizeY = float.Parse((listOfColumns[2]), CultureInfo.InvariantCulture.NumberFormat);

                    collectionOfSize.Add(sizeModel);
                }
            }
            catch (Exception ex)
            {
                _errorLogHelper.LogErrorAsync("BLMRepository", "GetAllSizeY", ex);
            }

            return collectionOfSize.OrderBy(x => x.SizeY).ToObservableCollection();
        }

        public ObservableCollection<ThicknessModel> GetAllThickness()
        {
            ObservableCollection<ThicknessModel> collectionOfThickness = new ObservableCollection<ThicknessModel>();

            try
            {
                StreamReader objInput = new StreamReader(new Uri(folderPath + "BLTHCK.DAT").LocalPath, System.Text.Encoding.Default);
                string contents = objInput.ReadToEnd().Trim();
                string[] splitRows = Regex.Split(contents, "\r\n", RegexOptions.None);
                foreach (string row in splitRows)
                {
                    string[] splitColumns = Regex.Split(row, " ", RegexOptions.None);
                    List<string> listOfColumns = splitColumns.Where(x => !string.IsNullOrEmpty(x)).ToList();

                    ThicknessModel thicknessModel = new ThicknessModel();
                    thicknessModel.ThicknessLong = float.Parse((listOfColumns[0]), CultureInfo.InvariantCulture.NumberFormat);
                    thicknessModel.ThicknessSmall = float.Parse((listOfColumns[1]), CultureInfo.InvariantCulture.NumberFormat);

                    collectionOfThickness.Add(thicknessModel);
                }
            }
            catch (Exception ex)
            {
                _errorLogHelper.LogErrorAsync("BLMRepository", "GetAllThickness", ex);
            }

            return collectionOfThickness.OrderBy(x => x.ThicknessSmall).ToObservableCollection();
        }

        public string GetInputUnit()
        {
            int inputUnit = 0;

            try
            {
                StreamReader objInput = new StreamReader(new Uri(folderPath + "FPPCNT.DAT").LocalPath, System.Text.Encoding.Default);
                string contents = objInput.ReadToEnd().Trim();
                string[] splitRows = Regex.Split(contents, "\r\n", RegexOptions.None);
                foreach (string row in splitRows.Take(1))
                {
                    string[] splitColumns = Regex.Split(row, ",", RegexOptions.None);
                    List<string> listOfColumns = splitColumns.Where(x => !string.IsNullOrEmpty(x)).ToList();

                    inputUnit = int.Parse((listOfColumns[4]), CultureInfo.InvariantCulture.NumberFormat);
                }

                StaticHelperClass.InputFormat = inputUnit == 0 ? "0.##" : "0.####";
                BlankSheetModel.MaxValueSupport = inputUnit == 0 ? Math.Round(9999.99, 2) : Math.Round(9999.9999, 4);
                BlankSheetModel.MaxValueSupportSmall = inputUnit == 0 ? Math.Round(99.99, 2) : Math.Round(99.9999, 4);
            }
            catch (Exception ex)
            {
                _errorLogHelper.LogErrorAsync("BLMRepository", "GetInputUnit", ex);
            }

            return inputUnit == 0 ? "mm" : "Inch";
        }

        public void SaveBlankSheet(ObservableCollection<BlankSheetModel> pcollectionOfBlankSheet)
        {
            try
            {
                using (StreamWriter streamWriter =
                new StreamWriter(new Uri(folderPath + "Blmaster.dat").LocalPath))
                {
                    foreach (var item in pcollectionOfBlankSheet)
                    {
                        streamWriter.WriteLine(item.MatCode.ToString().PadLeft(5)
                            + " " + item.BlankId.PadRight(15)
                            + "    " + $"{item.NewSizeX ?? item.SelectedSizeX.SizeX:0.0000}".PadLeft(9)
                            + "    " + $"{item.NewSizeY ?? item.SelectedSizeY.SizeY:0.0000}".PadLeft(9)
                            + " " + (string.IsNullOrEmpty(item.NewMaterial) ? item.SelectedMaterial.MaterialName.PadRight(10) : item.NewMaterial.PadRight(10))
                            + "    " +
                                               $"{item.NewThickness ?? item.SelectedThickness.ThicknessLong:0.0000}"
                                                   .PadLeft(9)
                            + "    " + $"{item.GripWidth:0.0000}".PadLeft(9)
                            + "    " + $"{item.TrimUp:0.0000}".PadLeft(9)
                            + "    " + $"{item.TrimRight:0.0000}".PadLeft(9)
                            + "    " + $"{item.TrimLeft:0.0000}".PadLeft(9)
                            + " " + item.StockQuantity.ToString().PadLeft(4)
                            + " " + item.SortingCode.ToString().PadLeft(4));
                    }
                }
            }
            catch (Exception ex)
            {
                _errorLogHelper.LogErrorAsync("BLMRepository", "SaveBlankSheet", ex);
            }
        }
        #endregion
    }
}
