﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;

namespace BLM.Helpers.Common
{
    public class TextBoxMaskBehavior
    {
        #region MinimumValue Property

        public static double GetMinimumValue(DependencyObject obj)
        {
            return (double)obj.GetValue(MinimumValueProperty);
        }

        public static void SetMinimumValue(DependencyObject obj, double value)
        {
            obj.SetValue(MinimumValueProperty, value);
        }

        public static readonly DependencyProperty MinimumValueProperty =
            DependencyProperty.RegisterAttached(
                "MinimumValue",
                typeof(double),
                typeof(TextBoxMaskBehavior),
                new FrameworkPropertyMetadata(double.NaN, MinimumValueChangedCallback)
                );

        private static void MinimumValueChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            TextBox _this = (d as TextBox);
            ValidateTextBox(_this);
        }
        #endregion

        #region MaximumValue Property

        public static double GetMaximumValue(DependencyObject obj)
        {
            return (double)obj.GetValue(MaximumValueProperty);
        }

        public static void SetMaximumValue(DependencyObject obj, double value)
        {
            obj.SetValue(MaximumValueProperty, value);
        }

        public static readonly DependencyProperty MaximumValueProperty =
            DependencyProperty.RegisterAttached(
                "MaximumValue",
                typeof(double),
                typeof(TextBoxMaskBehavior),
                new FrameworkPropertyMetadata(double.NaN, MaximumValueChangedCallback)
                );

        private static void MaximumValueChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            TextBox _this = (d as TextBox);
            ValidateTextBox(_this);
        }
        #endregion

        #region Mask Property

        public static MaskType GetMask(DependencyObject obj)
        {
            return (MaskType)obj.GetValue(MaskProperty);
        }

        public static void SetMask(DependencyObject obj, MaskType value)
        {
            obj.SetValue(MaskProperty, value);
        }

        public static readonly DependencyProperty MaskProperty =
            DependencyProperty.RegisterAttached(
                "Mask",
                typeof(MaskType),
                typeof(TextBoxMaskBehavior),
                new FrameworkPropertyMetadata(MaskChangedCallback)
                );

        private static void MaskChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var eOldValue = e.OldValue as TextBox;
            if (eOldValue != null)
            {
                eOldValue.PreviewTextInput -= TextBox_PreviewTextInput;
                eOldValue.PreviewLostKeyboardFocus -= _this_PreviewLostKeyboardFocus;
                DataObject.RemovePastingHandler(eOldValue, TextBoxPastingEventHandler);
            }

            TextBox _this = (d as TextBox);
            if (_this == null)
                return;


            if ((MaskType)e.NewValue != MaskType.Any)
            {
                _this.PreviewTextInput += TextBox_PreviewTextInput;
                _this.PreviewLostKeyboardFocus += _this_PreviewLostKeyboardFocus;
                DataObject.AddPastingHandler(_this, TextBoxPastingEventHandler);
            }

            ValidateTextBox(_this);
        }

        private static void _this_PreviewLostKeyboardFocus(object sender, System.Windows.Input.KeyboardFocusChangedEventArgs e)
        {
            TextBox textBox = e.Source as TextBox;

            if (textBox != null)
            {
                var textBindingExpression = textBox.GetBindingExpression(TextBox.TextProperty);

                if (textBindingExpression != null)
                {
                    // Forces to update the binding. As we are preventing the focus to be lost, its binding never updates and never recovers from a previous error.
                    textBindingExpression.UpdateSource();

                    var value = Validation.GetHasError(textBox);
                    if (value)
                    {
                        e.Handled = true;
                    }
                }
                else
                {
                    var comboBox = textBox.TemplatedParent as ComboBox;
                    var comboBindingExpression = comboBox?.GetBindingExpression(ComboBox.TextProperty);

                    if (comboBindingExpression != null)
                    {
                        // Forces to update the binding. As we are preventing the focus to be lost, its binding never updates and never recovers from a previous error.
                        comboBindingExpression.UpdateSource();

                        var value = Validation.GetHasError(comboBox);
                        if (value)
                        {
                            e.Handled = true;
                        }
                    }
                }
            }
        }

        #endregion

        #region Private Static Methods

        private static void ValidateTextBox(TextBox _this)
        {
            if (GetMask(_this) != MaskType.Any)
            {
                _this.Text = ValidateValue(GetMask(_this), _this.Text);
            }
        }

        private static void TextBoxPastingEventHandler(object sender, DataObjectPastingEventArgs e)
        {
            TextBox _this = (sender as TextBox);
            string clipboard = e.DataObject.GetData(typeof(string)) as string;
            clipboard = ValidateValue(GetMask(_this), clipboard);
            if (!string.IsNullOrEmpty(clipboard))
            {
                if (_this != null) _this.Text = clipboard;
            }
            e.CancelCommand();
            e.Handled = true;
        }

        private static void TextBox_PreviewTextInput(object sender, System.Windows.Input.TextCompositionEventArgs e)
        {
            TextBox _this = (sender as TextBox);

            //this is for BlankId and Material
            if (_this?.Tag != null && _this.Tag.ToString() == "anyset")
            {
                if (e.Text.Contains("?"))
                {
                    e.Handled = e.Text.Contains("?");
                    return;
                }

                e.Handled = false;
                return;
            }

            bool isValid = IsSymbolValid(GetMask(_this), e.Text);
            e.Handled = !isValid;
            if (isValid)
            {
                if (_this != null)
                {
                    int caret = _this.CaretIndex;
                    string text = _this.Text;
                    bool textInserted = false;
                    int selectionLength = 0;

                    if (_this.SelectionLength > 0)
                    {
                        text = text.Substring(0, _this.SelectionStart) +
                               text.Substring(_this.SelectionStart + _this.SelectionLength);
                        caret = _this.SelectionStart;
                    }

                    if (e.Text == NumberFormatInfo.CurrentInfo.NumberDecimalSeparator)
                    {
                        while (true)
                        {
                            int ind = text.IndexOf(NumberFormatInfo.CurrentInfo.NumberDecimalSeparator, StringComparison.Ordinal);
                            if (ind == -1)
                                break;

                            text = text.Substring(0, ind) + text.Substring(ind + 1);
                            if (caret > ind)
                                caret--;
                        }

                        if (caret == 0)
                        {
                            text = "0" + text;
                            caret++;
                        }
                        else
                        {
                            if (caret == 1 && string.Empty + text[0] == NumberFormatInfo.CurrentInfo.NegativeSign)
                            {
                                text = NumberFormatInfo.CurrentInfo.NegativeSign + "0" + text.Substring(1);
                                caret++;
                            }
                        }

                        if (caret == text.Length)
                        {
                            selectionLength = 1;
                            textInserted = true;
                            text = text + NumberFormatInfo.CurrentInfo.NumberDecimalSeparator + "0";
                            caret++;
                        }
                    }
                    else if (e.Text == NumberFormatInfo.CurrentInfo.NegativeSign)
                    {
                        textInserted = true;
                        if (_this.Text.Contains(NumberFormatInfo.CurrentInfo.NegativeSign))
                        {
                            text = text.Replace(NumberFormatInfo.CurrentInfo.NegativeSign, string.Empty);
                            if (caret != 0)
                                caret--;
                        }
                        else
                        {
                            text = NumberFormatInfo.CurrentInfo.NegativeSign + _this.Text;
                            caret++;
                        }
                    }

                    if (!textInserted)
                    {
                        text = text.Substring(0, caret) + e.Text +
                               ((caret < _this.Text.Length) ? text.Substring(caret) : string.Empty);

                        caret++;
                    }

                    try
                    {
                        decimal tempValue = Convert.ToDecimal(text);
                        double val = Convert.ToDouble(text);
                        double newVal = ValidateLimits(GetMinimumValue(_this), GetMaximumValue(_this), val, tempValue);
                        // ReSharper disable once CompareOfFloatsByEqualityOperator
                        if (val != newVal)
                        {
                            //text = newVal.ToString(CultureInfo.InvariantCulture);
                            e.Handled = false;
                            return;
                        }

                        // ReSharper disable once CompareOfFloatsByEqualityOperator
                        if (val == 0)
                        {
                            if (!text.Contains(NumberFormatInfo.CurrentInfo.NumberDecimalSeparator))
                                text = "0";
                        }

                        //this is for (if I type 1 and then try to select any value starting with 1 from combo, it is not selecting that value.)
                        // ReSharper disable once CompareOfFloatsByEqualityOperator
                        if (_this.Tag != null && text.Length < 2 && (_this.Tag.ToString() == "max4" && val != GetMaximumValue(_this)))
                        {
                            e.Handled = false;
                            return;
                        }
                    }
                    catch
                    {
                        text = "0";
                    }

                    while (text.Length > 1 && text[0] == '0' && string.Empty + text[1] != NumberFormatInfo.CurrentInfo.NumberDecimalSeparator)
                    {
                        text = text.Substring(1);
                        if (caret > 0)
                            caret--;
                    }

                    while (text.Length > 2 && string.Empty + text[0] == NumberFormatInfo.CurrentInfo.NegativeSign && text[1] == '0' && string.Empty + text[2] != NumberFormatInfo.CurrentInfo.NumberDecimalSeparator)
                    {
                        text = NumberFormatInfo.CurrentInfo.NegativeSign + text.Substring(2);
                        if (caret > 1)
                            caret--;
                    }

                    if (caret > text.Length)
                        caret = text.Length;

                    _this.Text = text;
                    _this.CaretIndex = caret;
                    _this.SelectionStart = caret;
                    _this.SelectionLength = selectionLength;
                }
                e.Handled = true;
            }
        }

        private static string ValidateValue(MaskType mask, string value)
        {
            if (string.IsNullOrEmpty(value))
                return string.Empty;

            value = value.Trim();
            switch (mask)
            {
                case MaskType.Integer:
                    try
                    {
                        return value;
                    }
                    catch
                    {
                        // ignored
                    }
                    return string.Empty;

                case MaskType.Decimal:
                    try
                    {
                        return value;
                    }
                    catch
                    {
                        // ignored
                    }
                    return string.Empty;
            }

            return value;
        }

        private static double ValidateLimits(double min, double max, double value, decimal tempValue = 0)
        {
            if (!min.Equals(double.NaN))
            {
                if (value < min)
                    return min;
            }

            if (!max.Equals(double.NaN))
            {
                int maxValue = max.ToString(CultureInfo.InvariantCulture).Substring(0, max.ToString(CultureInfo.InvariantCulture).IndexOf(".", StringComparison.Ordinal)).Length;
                int maxPointValue = max.ToString(CultureInfo.InvariantCulture).Substring(max.ToString(CultureInfo.InvariantCulture).IndexOf(".", StringComparison.Ordinal) + 1).Length;

                int inputValue = value.ToString(CultureInfo.InvariantCulture).IndexOf(".", StringComparison.Ordinal) == -1 ? (int)value : value.ToString(CultureInfo.InvariantCulture).Substring(0, value.ToString(CultureInfo.InvariantCulture).IndexOf(".", StringComparison.Ordinal)).Length;
                int inputPointValue = value.ToString(CultureInfo.InvariantCulture).IndexOf(".", StringComparison.Ordinal) == -1 ? 0 : value.ToString(CultureInfo.InvariantCulture).Substring(value.ToString(CultureInfo.InvariantCulture).IndexOf(".", StringComparison.Ordinal) + 1).Length;

                if (tempValue.ToString(CultureInfo.InvariantCulture).IndexOf(".", StringComparison.Ordinal) != -1)
                {
                    inputValue = tempValue.ToString(CultureInfo.InvariantCulture).IndexOf(".", StringComparison.Ordinal) == -1 ? (int)tempValue : tempValue.ToString(CultureInfo.InvariantCulture).Substring(0, tempValue.ToString(CultureInfo.InvariantCulture).IndexOf(".", StringComparison.Ordinal)).Length;
                    inputPointValue = tempValue.ToString(CultureInfo.InvariantCulture).IndexOf(".", StringComparison.Ordinal) == -1 ? 0 : tempValue.ToString(CultureInfo.InvariantCulture).Substring(tempValue.ToString(CultureInfo.InvariantCulture).IndexOf(".", StringComparison.Ordinal) + 1).Length;
                }

                if (value > max || maxValue < inputValue)
                    return max;

                if (inputPointValue != 0 && maxPointValue < inputPointValue)
                    return max;

                //if (value > max || max.ToString().Length < value.ToString().Length)
                //    return max;
            }

            return value;
        }

        private static bool IsSymbolValid(MaskType mask, string str)
        {
            switch (mask)
            {
                case MaskType.Any:
                    return true;

                case MaskType.Integer:
                    if (str == NumberFormatInfo.CurrentInfo.NegativeSign)
                        return true;
                    break;

                case MaskType.Decimal:
                    if (str == NumberFormatInfo.CurrentInfo.NumberDecimalSeparator ||
                        str == NumberFormatInfo.CurrentInfo.NegativeSign)
                        return true;
                    break;
            }

            if (mask.Equals(MaskType.Integer) || mask.Equals(MaskType.Decimal))
            {
                foreach (char ch in str)
                {
                    if (!Char.IsDigit(ch))
                        return false;
                }

                return true;
            }

            return false;
        }

        #endregion
    }

    public enum MaskType
    {
        Any,
        Integer,
        Decimal
    }
}
