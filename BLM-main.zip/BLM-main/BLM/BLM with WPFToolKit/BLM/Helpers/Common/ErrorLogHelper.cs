﻿using System;
using System.IO;

namespace BLM.Helpers.Common
{
    public class ErrorLogHelper
    {
        #region Methods
        /// <summary>
        /// this is for log error
        /// </summary>
        /// <param name="className"></param>
        /// <param name="methodName"></param>
        /// <param name="ex"></param>
        public void LogErrorAsync(string className, string methodName, Exception ex)
        {
            try
            {
                var folderPath = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase) + "/Logs/";
                var filePath = folderPath + DateTime.Now.ToString("yyyy-MM-dd") + ".txt";

                if (!Directory.Exists(folderPath)) { Directory.CreateDirectory(folderPath); }

                using (var sw = new StreamWriter(filePath, true))
                {
                    sw.WriteLine(DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"));
                    sw.WriteLine($"{className}, {methodName}");
                    sw.WriteLine(ex.Message);
                    sw.WriteLine(ex.InnerException?.ToString() ?? string.Empty);
                    sw.WriteLine(ex.StackTrace + Environment.NewLine + Environment.NewLine);
                }
            }
            catch
            {
                // ignored
            }
        }
        #endregion
    }
}
