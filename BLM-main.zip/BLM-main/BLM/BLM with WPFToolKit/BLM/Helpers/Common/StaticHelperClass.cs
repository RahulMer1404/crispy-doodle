﻿namespace BLM.Helpers.Common
{
    public static class StaticHelperClass
    {
        public static string InputFormat { get; set; }
    }
}
