﻿using System;
using System.Diagnostics;
using System.Windows.Input;

namespace BLM.Helpers.Common
{
    public class DelegateCommand : ICommand
    {
        #region Fields

        readonly Action<object> _execute;
        readonly Predicate<object> _canExecute;
        public static Stopwatch Stopwatch;

        #endregion // Fields

        #region Constructors

        public DelegateCommand(Action<object> execute)
            : this(execute, null)
        {
        }

        public DelegateCommand(Action<object> execute, Predicate<object> canExecute)
        {
            if (execute == null)
                throw new ArgumentNullException("execute");

            _execute = execute;
            _canExecute = canExecute;
        }

        #endregion // Constructors

        #region ICommand Members

        [DebuggerStepThrough]
        public bool CanExecute(object parameter)
        {
            return _canExecute == null ? true : _canExecute(parameter);
        }

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public void Execute(object parameter)
        {
            Mouse.OverrideCursor = Cursors.Wait;
            try
            {
                IsBusy = true;
                _execute(parameter);
            }
            finally
            {
                Mouse.OverrideCursor = null;
                IsBusy = false;
            }

        }

        #endregion // ICommand Members

        #region UpdateBusy
        static bool _isBusy;
        public static bool IsBusy
        {
            get
            {
                return _isBusy;
            }
            set
            {
                _isBusy = value;
                OnBusyChange();
            }
        }

        public static event EventHandler BusyChange;
        public static void OnBusyChange()
        {
            BusyChange?.Invoke(null, EventArgs.Empty);
        }
        #endregion // UpdateBusy
    }
}
