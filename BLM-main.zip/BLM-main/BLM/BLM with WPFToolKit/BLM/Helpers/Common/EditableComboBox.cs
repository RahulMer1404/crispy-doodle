﻿using BLM.Models;
using System.Windows;
using System.Windows.Controls;

namespace BLM.Helpers.Common
{
    public class EditableComboBox
    {
        #region attached properties
        /// <summary>
        /// this is for get max length
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static int GetMaxLength(DependencyObject obj)
        {
            return (int)obj.GetValue(MaxLengthProperty);
        }

        /// <summary>
        /// this is for set max length
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="value"></param>
        public static void SetMaxLength(DependencyObject obj, int value)
        {
            obj.SetValue(MaxLengthProperty, value);
        }
        #endregion

        #region Dependency Property
        // Using a DependencyProperty as the backing store for MaxLength.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MaxLengthProperty = DependencyProperty.RegisterAttached("MaxLength", typeof(int), typeof(EditableComboBox), new UIPropertyMetadata(OnMaxLenghtChanged));
        #endregion

        #region Events
        //max lenght changed events
        private static void OnMaxLenghtChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            var comboBox = obj as ComboBox;
            if (comboBox == null) return;

            comboBox.Loaded +=
                (s, e) =>
                {
                    var textBox = comboBox.FindChild(typeof(TextBox), "PART_EditableTextBox");
                    if (textBox == null) return;

                    textBox.SetValue(TextBox.MaxLengthProperty, args.NewValue);

                    if (comboBox.Tag == null)
                        return;

                    if (comboBox.Tag != null && comboBox.Tag.ToString() == "anyset")
                    {
                        TextBoxMaskBehavior.SetMask(textBox, MaskType.Decimal);
                        textBox.SetValue(FrameworkElement.TagProperty, "anyset");
                    }

                    if (comboBox.Tag.ToString() == "max2")
                    {
                        textBox.SetValue(TextBox.TextAlignmentProperty, TextAlignment.Right);
                        TextBoxMaskBehavior.SetMask(textBox, MaskType.Decimal);
                        TextBoxMaskBehavior.SetMinimumValue(textBox, 0);
                        TextBoxMaskBehavior.SetMaximumValue(textBox, BlankSheetModel.MaxValueSupportSmall);
                    }

                    if (comboBox.Tag.ToString() == "max4")
                    {
                        textBox.SetValue(TextBox.TextAlignmentProperty, TextAlignment.Right);
                        TextBoxMaskBehavior.SetMask(textBox, MaskType.Decimal);
                        TextBoxMaskBehavior.SetMinimumValue(textBox, 0);
                        TextBoxMaskBehavior.SetMaximumValue(textBox, BlankSheetModel.MaxValueSupport);
                        textBox.SetValue(FrameworkElement.TagProperty, "max4");
                    }
                };
        }
        #endregion
    }
}
