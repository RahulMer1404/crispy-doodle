﻿using BLM.ViewModels;
using Microsoft.Windows.Controls.Primitives;

namespace BLM
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow
    {
        #region Variables
        internal MainViewModel MainViewModel { get; private set; }
        #endregion

        #region Ctor
        public MainWindow()
        {
            InitializeComponent();
            
            MainViewModel = new MainViewModel();
            DataContext = MainViewModel;
            //this.Resources["inputFormat"] = StaticHelperClass.InputFormat;
        }
        #endregion

        #region Events
        private void Header_MouseRightButtonUp(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            DataGridColumnHeader _DataGridColumnHeader = sender as DataGridColumnHeader;
            if(_DataGridColumnHeader.Content.ToString() == "Sr No" || _DataGridColumnHeader.Content.ToString() == "Data Edited or New Added")
            {
                e.Handled = true;
                return;
            }

            MainViewModel mainViewModel = DataContext as MainViewModel;
            mainViewModel?.OpenFilterOptionsCommand.Execute(_DataGridColumnHeader.Content);
        }
        #endregion
    }
}
